import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, onAuthStateChanged, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { auth, db } from '@/lib/firebase';

interface UserProfile {
  id: string;
  email: string;
  name: string;
  phone?: string;
  address?: string;
  isAdmin: boolean;
}

interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<{ error?: string }>;
  register: (email: string, password: string, name: string) => Promise<{ error?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      
      if (firebaseUser) {
        // Fetch user profile
        const profileDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
        if (profileDoc.exists()) {
          setProfile(profileDoc.data() as UserProfile);
        }
      } else {
        setProfile(null);
      }
      
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, password: string): Promise<{ error?: string }> => {
    try {
      await signInWithEmailAndPassword(auth, email, password);
      return {};
    } catch (error: any) {
      let message = 'লগইন ব্যর্থ হয়েছে';
      if (error.code === 'auth/invalid-email') {
        message = 'ইমেইল ঠিকানা সঠিক নয়';
      } else if (error.code === 'auth/user-not-found') {
        message = 'এই ইমেইলে কোনো অ্যাকাউন্ট নেই';
      } else if (error.code === 'auth/wrong-password') {
        message = 'পাসওয়ার্ড সঠিক নয়';
      } else if (error.code === 'auth/invalid-credential') {
        message = 'ইমেইল বা পাসওয়ার্ড সঠিক নয়';
      }
      return { error: message };
    }
  };

  const register = async (email: string, password: string, name: string): Promise<{ error?: string }> => {
    try {
      const { user: newUser } = await createUserWithEmailAndPassword(auth, email, password);
      
      // Create user profile in Firestore
      const userProfile: UserProfile = {
        id: newUser.uid,
        email: email,
        name: name,
        isAdmin: false
      };
      
      await setDoc(doc(db, 'users', newUser.uid), userProfile);
      setProfile(userProfile);
      
      return {};
    } catch (error: any) {
      let message = 'রেজিস্ট্রেশন ব্যর্থ হয়েছে';
      if (error.code === 'auth/email-already-in-use') {
        message = 'এই ইমেইলে ইতিমধ্যে অ্যাকাউন্ট আছে';
      } else if (error.code === 'auth/weak-password') {
        message = 'পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে';
      } else if (error.code === 'auth/invalid-email') {
        message = 'ইমেইল ঠিকানা সঠিক নয়';
      }
      return { error: message };
    }
  };

  const logout = async () => {
    await signOut(auth);
    setProfile(null);
  };

  return (
    <AuthContext.Provider value={{ user, profile, loading, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
