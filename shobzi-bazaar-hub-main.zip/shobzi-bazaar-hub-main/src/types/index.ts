export interface Product {
  id: string;
  name: string;
  nameBn: string;
  price: number;
  originalPrice?: number;
  unit: string;
  image: string;
  category: string;
  description?: string;
  descriptionBn?: string;
  inStock: boolean;
  discount?: number;
  stockQuantity?: number;
  isActive?: boolean;
}

export interface Category {
  id: string;
  name: string;
  nameBn: string;
  icon: string;
  image: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface User {
  id: string;
  email: string;
  name: string;
  phone?: string;
  address?: string;
  isAdmin?: boolean;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  subtotal: number;
  deliveryCharge: number;
  couponDiscount?: number;
  couponCode?: string;
  status: 'pending' | 'confirmed' | 'processing' | 'delivered' | 'cancelled';
  paymentMethod: 'cod' | 'bkash' | 'online';
  paymentStatus: 'unpaid' | 'paid';
  address: string;
  phone: string;
  customerName: string;
  deliveryArea?: string;
  createdAt: Date;
}

export interface DeliveryArea {
  id: string;
  name: string;
  nameBn: string;
  charge: number;
  isActive: boolean;
}

export interface DeliverySettings {
  defaultCharge: number;
  freeDeliveryMinOrder: number;
  areas: DeliveryArea[];
  deliveryManName?: string;
  deliveryManPhone?: string;
  courierName?: string;
  estimatedTime?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount: number;
  maxDiscount?: number;
  isActive: boolean;
  expiresAt?: Date;
  freeDelivery: boolean;
  applicableProductIds?: string[];
  usageCount: number;
}

export interface Banner {
  id: string;
  title: string;
  titleBn: string;
  subtitle?: string;
  subtitleBn?: string;
  image: string;
  link?: string;
  type: 'hero' | 'offer' | 'festival';
  isActive: boolean;
  order: number;
  buttonText?: string;
  buttonTextBn?: string;
}

export interface SiteSettings {
  storeName: string;
  storeNameBn: string;
  logo?: string;
  phone: string;
  email?: string;
  address: string;
  addressBn?: string;
  deliveryTime: string;
  openTime: string;
  closeTime: string;
  isOpen: boolean;
  facebookUrl?: string;
  instagramUrl?: string;
  whatsappNumber?: string;
}
