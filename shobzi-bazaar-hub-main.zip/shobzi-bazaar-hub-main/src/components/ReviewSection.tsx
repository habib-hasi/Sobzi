import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, User, ThumbsUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { toast } from '@/hooks/use-toast';
import { collection, addDoc, getDocs, query, where, orderBy, Timestamp, updateDoc, doc } from 'firebase/firestore';
import { db } from '@/lib/firebase';

interface Review {
  id: string;
  productId: string;
  name: string;
  rating: number;
  comment: string;
  createdAt: Date;
  likes: number;
}

interface ReviewSectionProps {
  productId: string;
  productName: string;
}

const ReviewSection = ({ productId, productName }: ReviewSectionProps) => {
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [newReview, setNewReview] = useState({ name: '', rating: 5, comment: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const q = query(
          collection(db, 'reviews'),
          where('productId', '==', productId)
        );
        const snapshot = await getDocs(q);
        const reviewList = snapshot.docs.map(d => ({
          id: d.id,
          ...d.data(),
          createdAt: d.data().createdAt?.toDate?.() || new Date()
        })) as Review[];
        setReviews(reviewList.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime()));
      } catch (error) {
        console.error('Error fetching reviews:', error);
      }
      setLoading(false);
    };
    fetchReviews();
  }, [productId]);

  const handleSubmit = async () => {
    if (!newReview.name.trim() || !newReview.comment.trim()) {
      toast({ title: 'নাম ও মন্তব্য লিখুন', variant: 'destructive' });
      return;
    }

    setSubmitting(true);
    try {
      const reviewData = {
        productId,
        name: newReview.name,
        rating: newReview.rating,
        comment: newReview.comment,
        likes: 0,
        createdAt: Timestamp.now()
      };
      const docRef = await addDoc(collection(db, 'reviews'), reviewData);
      
      setReviews(prev => [{
        id: docRef.id,
        ...reviewData,
        createdAt: new Date()
      }, ...prev]);
      setNewReview({ name: '', rating: 5, comment: '' });
      setShowForm(false);
      toast({ title: 'রিভিউ যোগ হয়েছে! ধন্যবাদ 🎉' });
    } catch (error) {
      console.error('Error saving review:', error);
      toast({ title: 'রিভিউ সেভ করতে সমস্যা হয়েছে', variant: 'destructive' });
    }
    setSubmitting(false);
  };

  const handleLike = async (reviewId: string) => {
    try {
      const review = reviews.find(r => r.id === reviewId);
      if (!review) return;
      await updateDoc(doc(db, 'reviews', reviewId), { likes: review.likes + 1 });
      setReviews(prev =>
        prev.map(r => (r.id === reviewId ? { ...r, likes: r.likes + 1 } : r))
      );
    } catch (error) {
      console.error('Error liking review:', error);
    }
  };

  const formatDate = (date: Date) => {
    const now = new Date();
    const diff = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
    if (diff === 0) return 'আজ';
    if (diff === 1) return 'গতকাল';
    if (diff < 7) return `${diff} দিন আগে`;
    if (diff < 30) return `${Math.floor(diff / 7)} সপ্তাহ আগে`;
    return `${Math.floor(diff / 30)} মাস আগে`;
  };

  const avgRating = reviews.length
    ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
    : '0';

  return (
    <section className="mt-12 sm:mt-16">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold font-bengali text-foreground">
            কাস্টমার রিভিউ
          </h2>
          <div className="flex items-center gap-2 mt-1">
            <div className="flex items-center gap-0.5">
              {[1, 2, 3, 4, 5].map(star => (
                <Star
                  key={star}
                  className={`h-4 w-4 ${
                    star <= Math.round(Number(avgRating))
                      ? 'fill-warning text-warning'
                      : 'text-border'
                  }`}
                />
              ))}
            </div>
            <span className="text-sm text-muted-foreground">
              {avgRating} ({reviews.length} রিভিউ)
            </span>
          </div>
        </div>
        <Button
          onClick={() => setShowForm(!showForm)}
          className="btn-primary rounded-full"
        >
          রিভিউ লিখুন
        </Button>
      </div>

      {/* Review Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="bg-card rounded-xl p-4 sm:p-6 mb-6 shadow-card overflow-hidden"
          >
            <h3 className="font-semibold text-foreground mb-4">{productName} সম্পর্কে আপনার মতামত</h3>

            <div className="space-y-4">
              <div>
                <label className="text-sm text-muted-foreground mb-1 block">আপনার নাম</label>
                <Input
                  value={newReview.name}
                  onChange={e => setNewReview(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="নাম লিখুন"
                  className="rounded-lg"
                />
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-2 block">রেটিং</label>
                <div className="flex items-center gap-1">
                  {[1, 2, 3, 4, 5].map(star => (
                    <button
                      key={star}
                      type="button"
                      onClick={() => setNewReview(prev => ({ ...prev, rating: star }))}
                      className="p-0.5"
                    >
                      <Star
                        className={`h-6 w-6 transition-colors ${
                          star <= newReview.rating
                            ? 'fill-warning text-warning'
                            : 'text-border hover:text-warning/50'
                        }`}
                      />
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-sm text-muted-foreground mb-1 block">মন্তব্য</label>
                <Textarea
                  value={newReview.comment}
                  onChange={e => setNewReview(prev => ({ ...prev, comment: e.target.value }))}
                  placeholder="পণ্য সম্পর্কে আপনার অভিজ্ঞতা শেয়ার করুন..."
                  rows={3}
                  className="rounded-lg"
                />
              </div>

              <div className="flex gap-2">
                <Button onClick={handleSubmit} disabled={submitting} className="btn-primary rounded-full">
                  {submitting ? 'সেভ হচ্ছে...' : 'রিভিউ জমা দিন'}
                </Button>
                <Button variant="outline" onClick={() => setShowForm(false)} className="rounded-full">
                  বাতিল
                </Button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Reviews List */}
      {loading ? (
        <div className="text-center py-6 text-muted-foreground text-sm">রিভিউ লোড হচ্ছে...</div>
      ) : (
        <div className="space-y-4">
          {reviews.map((review, index) => (
            <motion.div
              key={review.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
              className="bg-card rounded-xl p-4 sm:p-5 shadow-sm"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-10 w-10 rounded-full bg-accent flex items-center justify-center">
                    <User className="h-5 w-5 text-accent-foreground" />
                  </div>
                  <div>
                    <p className="font-medium text-foreground text-sm">{review.name}</p>
                    <div className="flex items-center gap-1.5">
                      <div className="flex">
                        {[1, 2, 3, 4, 5].map(star => (
                          <Star
                            key={star}
                            className={`h-3 w-3 ${
                              star <= review.rating
                                ? 'fill-warning text-warning'
                                : 'text-border'
                            }`}
                          />
                        ))}
                      </div>
                      <span className="text-xs text-muted-foreground">{formatDate(review.createdAt)}</span>
                    </div>
                  </div>
                </div>
              </div>
              <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{review.comment}</p>
              <button
                onClick={() => handleLike(review.id)}
                className="flex items-center gap-1.5 mt-3 text-xs text-muted-foreground hover:text-primary transition-colors"
              >
                <ThumbsUp className="h-3.5 w-3.5" />
                সহায়ক ({review.likes})
              </button>
            </motion.div>
          ))}
        </div>
      )}

      {!loading && reviews.length === 0 && (
        <div className="text-center py-10 text-muted-foreground">
          <p>এখনো কোনো রিভিউ নেই। প্রথম রিভিউ দিন!</p>
        </div>
      )}
    </section>
  );
};

export default ReviewSection;
