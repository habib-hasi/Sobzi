import { Facebook, MessageCircle, Send, Copy, Share2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from '@/hooks/use-toast';

interface ShareButtonsProps {
  url: string;
  title: string;
}

const ShareButtons = ({ url, title }: ShareButtonsProps) => {
  const encodedUrl = encodeURIComponent(url);
  const encodedTitle = encodeURIComponent(title);

  const shareLinks = [
    {
      name: 'Facebook',
      icon: Facebook,
      href: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
      className: 'bg-[hsl(221,44%,41%)] hover:bg-[hsl(221,44%,35%)] text-white',
    },
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      href: `https://wa.me/?text=${encodedTitle}%20${encodedUrl}`,
      className: 'bg-[hsl(142,70%,40%)] hover:bg-[hsl(142,70%,35%)] text-white',
    },
    {
      name: 'Messenger',
      icon: Send,
      href: `https://www.facebook.com/dialog/send?link=${encodedUrl}&app_id=123456&redirect_uri=${encodedUrl}`,
      className: 'bg-[hsl(250,70%,55%)] hover:bg-[hsl(250,70%,48%)] text-white',
    },
  ];

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      toast({ title: 'লিংক কপি হয়েছে!' });
    } catch {
      toast({ title: 'কপি করা যায়নি', variant: 'destructive' });
    }
  };

  return (
    <div className="border-t border-border pt-4">
      <div className="flex items-center gap-2 mb-3">
        <Share2 className="h-4 w-4 text-muted-foreground" />
        <span className="text-sm font-medium text-muted-foreground">শেয়ার করুন</span>
      </div>
      <div className="flex items-center gap-2 flex-wrap">
        {shareLinks.map(link => (
          <a
            key={link.name}
            href={link.href}
            target="_blank"
            rel="noopener noreferrer"
            className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-medium transition-all ${link.className}`}
          >
            <link.icon className="h-3.5 w-3.5" />
            {link.name}
          </a>
        ))}
        <Button
          variant="outline"
          size="sm"
          onClick={handleCopy}
          className="rounded-full h-auto py-2 px-3 text-xs"
        >
          <Copy className="h-3.5 w-3.5 mr-1" />
          লিংক কপি
        </Button>
      </div>
    </div>
  );
};

export default ShareButtons;
