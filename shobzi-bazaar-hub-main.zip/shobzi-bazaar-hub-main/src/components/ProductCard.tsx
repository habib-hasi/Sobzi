import { motion } from 'framer-motion';
import { Plus, Minus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product } from '@/types';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';

interface ProductCardProps {
  product: Product;
}

const ProductCard = ({ product }: ProductCardProps) => {
  const { items, addToCart, updateQuantity } = useCart();
  const cartItem = items.find(item => item.id === product.id);
  const quantity = cartItem?.quantity || 0;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ y: -4 }}
      className="card-product relative overflow-hidden"
    >
      {/* Discount Badge */}
      {product.discount && (
        <div className="absolute top-3 left-3 z-10">
          <span className="badge-offer">
            {product.discount}% ছাড়
          </span>
        </div>
      )}

      {/* Product Image */}
      <Link to={`/product/${product.id}`}>
        <div className="relative aspect-square bg-muted overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
          />
          {!product.inStock && (
            <div className="absolute inset-0 bg-foreground/50 flex items-center justify-center">
              <span className="bg-destructive text-destructive-foreground px-3 py-1 rounded-full text-sm font-medium">
                স্টক শেষ
              </span>
            </div>
          )}
        </div>
      </Link>

      {/* Product Info */}
      <div className="p-3 sm:p-4">
        <Link to={`/product/${product.id}`}>
          <h3 className="font-semibold text-sm sm:text-base font-bengali text-foreground line-clamp-1 hover:text-primary transition-colors">
            {product.nameBn}
          </h3>
        </Link>
        <p className="text-xs text-muted-foreground mb-2">{product.unit}</p>

        {/* Price */}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-lg font-bold text-primary">৳{product.price}</span>
          {product.originalPrice && (
            <span className="text-sm text-muted-foreground line-through">
              ৳{product.originalPrice}
            </span>
          )}
        </div>

        {/* Add to Cart Button */}
        {product.inStock && (
          <>
            {quantity === 0 ? (
              <motion.div whileTap={{ scale: 0.95 }}>
                <Button
                  onClick={() => addToCart(product)}
                  className="w-full btn-primary rounded-full h-10"
                >
                  <Plus className="h-4 w-4 mr-1" />
                  কার্টে যোগ করুন
                </Button>
              </motion.div>
            ) : (
              <div className="flex items-center justify-between bg-accent rounded-full p-1">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => updateQuantity(product.id, quantity - 1)}
                  className="h-8 w-8 rounded-full hover:bg-primary hover:text-primary-foreground"
                >
                  <Minus className="h-4 w-4" />
                </Button>
                <span className="font-semibold text-foreground">{quantity}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => updateQuantity(product.id, quantity + 1)}
                  className="h-8 w-8 rounded-full hover:bg-primary hover:text-primary-foreground"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </motion.div>
  );
};

export default ProductCard;
