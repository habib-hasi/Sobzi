import { motion } from 'framer-motion';
import { ArrowRight, Truck, Clock, Shield } from 'lucide-react';
import { Button } from '@/components/ui/button';
import heroImage from '@/assets/hero-groceries.jpg';

const HeroBanner = () => {
  return (
    <section className="relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0">
        <img
          src={heroImage}
          alt="Fresh groceries"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-foreground/90 via-foreground/70 to-transparent" />
      </div>

      {/* Content */}
      <div className="relative container py-12 sm:py-20 lg:py-28">
        <div className="max-w-xl">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <span className="inline-block bg-secondary text-secondary-foreground px-4 py-1.5 rounded-full text-sm font-medium mb-4">
              🎉 প্রথম অর্ডারে ২০% ছাড়!
            </span>
            
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-card mb-4 font-bengali leading-tight">
              তাজা শাকসবজি ও মুদি পণ্য
              <span className="block text-secondary">আপনার দোরগোড়ায়!</span>
            </h1>

            <p className="text-card/80 text-base sm:text-lg mb-6 max-w-md">
              সবজি বাজার থেকে সেরা দামে কিনুন তাজা শাকসবজি, ফলমূল, চাল, ডাল ও মসলা। 
              দ্রুত ডেলিভারি গ্যারান্টি!
            </p>

            <div className="flex flex-wrap gap-3">
              <Button className="btn-secondary h-12 px-6 rounded-full text-base">
                এখনই কিনুন
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button variant="outline" className="h-12 px-6 rounded-full text-base bg-card/10 text-card border-card/30 hover:bg-card/20">
                অফার দেখুন
              </Button>
            </div>
          </motion.div>

          {/* Features */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-4 sm:gap-6 mt-8 sm:mt-12"
          >
            <div className="flex items-center gap-2 text-card/90">
              <div className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center">
                <Truck className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-medium">ফ্রি ডেলিভারি</p>
                <p className="text-xs text-card/60">৫০০৳+ অর্ডারে</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-card/90">
              <div className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center">
                <Clock className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-medium">দ্রুত ডেলিভারি</p>
                <p className="text-xs text-card/60">২-৪ ঘন্টায়</p>
              </div>
            </div>

            <div className="flex items-center gap-2 text-card/90">
              <div className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center">
                <Shield className="h-5 w-5" />
              </div>
              <div>
                <p className="text-sm font-medium">১০০% তাজা</p>
                <p className="text-xs text-card/60">গ্যারান্টি</p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default HeroBanner;
