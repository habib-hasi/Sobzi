import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingCart, Search, Menu, X, User, MapPin, ChevronDown, LogOut } from 'lucide-react';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const { totalItems, totalPrice } = useCart();
  const { user, profile, logout } = useAuth();
  const location = useLocation();

  const isAdmin = location.pathname.startsWith('/admin');

  const handleLogout = async () => {
    await logout();
  };

  return (
    <header className="sticky top-0 z-50 bg-card shadow-md">
      {/* Top Bar */}
      <div className="hero-gradient text-primary-foreground py-2">
        <div className="container flex items-center justify-between text-sm">
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            <span className="hidden sm:inline">ঢাকা, বাংলাদেশ</span>
            <ChevronDown className="h-4 w-4" />
          </div>
          <div className="flex items-center gap-4">
            <span className="text-xs sm:text-sm">🚚 ফ্রি ডেলিভারি ৫০০৳+ অর্ডারে</span>
          </div>
        </div>
      </div>

      {/* Main Header */}
      <div className="container py-3">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="flex items-center gap-2"
            >
              <span className="text-3xl">🥬</span>
              <div>
                <h1 className="text-xl sm:text-2xl font-bold text-gradient font-bengali">
                  সবজি বাজার
                </h1>
                <span className="text-xs text-muted-foreground hidden sm:block">
                  Sobji Bazar
                </span>
              </div>
            </motion.div>
          </Link>

          {/* Search Bar - Desktop */}
          <div className="hidden md:flex flex-1 max-w-xl">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
              <Input
                type="text"
                placeholder="আপনার প্রয়োজনীয় পণ্য খুঁজুন..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4 h-12 rounded-full bg-muted border-none focus-visible:ring-primary"
              />
            </div>
          </div>

          {/* Right Actions */}
          <div className="flex items-center gap-2 sm:gap-4">
            {!isAdmin && (
              <>
                {/* User Menu */}
                {user ? (
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="sm" className="gap-2">
                        <User className="h-5 w-5" />
                        <span className="hidden sm:inline">{profile?.name || 'অ্যাকাউন্ট'}</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link to="/orders" className="cursor-pointer">
                          📦 আমার অর্ডার
                        </Link>
                      </DropdownMenuItem>
                      {profile?.isAdmin && (
                        <DropdownMenuItem asChild>
                          <Link to="/admin" className="cursor-pointer">
                            ⚙️ অ্যাডমিন
                          </Link>
                        </DropdownMenuItem>
                      )}
                      <DropdownMenuSeparator />
                      <DropdownMenuItem onClick={handleLogout} className="text-destructive cursor-pointer">
                        <LogOut className="h-4 w-4 mr-2" />
                        লগআউট
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                ) : (
                  <Link to="/auth">
                    <Button variant="ghost" size="sm" className="gap-2">
                      <User className="h-5 w-5" />
                      <span className="hidden sm:inline">লগইন</span>
                    </Button>
                  </Link>
                )}

                {/* Cart Button */}
                <Link to="/cart">
                  <motion.div
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="relative"
                  >
                    <Button className="btn-primary h-12 px-4 sm:px-6 rounded-full gap-2">
                      <ShoppingCart className="h-5 w-5" />
                      <span className="hidden sm:inline">{totalItems} আইটেম</span>
                      <span className="font-bold">৳{totalPrice}</span>
                    </Button>
                    {totalItems > 0 && (
                      <motion.span
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        className="absolute -top-2 -right-2 bg-secondary text-secondary-foreground text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center"
                      >
                        {totalItems}
                      </motion.span>
                    )}
                  </motion.div>
                </Link>
              </>
            )}

            {isAdmin && (
              <Link to="/">
                <Button variant="outline" size="sm">
                  🏠 হোম
                </Button>
              </Link>
            )}

            {/* Mobile Menu Toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Search */}
        <div className="md:hidden mt-3">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-muted-foreground" />
            <Input
              type="text"
              placeholder="পণ্য খুঁজুন..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10 pr-4 h-11 rounded-full bg-muted border-none"
            />
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="md:hidden bg-card border-t overflow-hidden"
          >
            <nav className="container py-4 space-y-2">
              <Link
                to="/"
                className="block py-2 px-4 rounded-lg hover:bg-muted transition-colors"
                onClick={() => setIsMenuOpen(false)}
              >
                🏠 হোম
              </Link>
              {user ? (
                <>
                  <Link
                    to="/orders"
                    className="block py-2 px-4 rounded-lg hover:bg-muted transition-colors"
                    onClick={() => setIsMenuOpen(false)}
                  >
                    📦 আমার অর্ডার
                  </Link>
                  {profile?.isAdmin && (
                    <Link
                      to="/admin"
                      className="block py-2 px-4 rounded-lg hover:bg-muted transition-colors"
                      onClick={() => setIsMenuOpen(false)}
                    >
                      ⚙️ অ্যাডমিন
                    </Link>
                  )}
                  <button
                    onClick={() => {
                      handleLogout();
                      setIsMenuOpen(false);
                    }}
                    className="block w-full text-left py-2 px-4 rounded-lg hover:bg-muted transition-colors text-destructive"
                  >
                    🚪 লগআউট
                  </button>
                </>
              ) : (
                <Link
                  to="/auth"
                  className="block py-2 px-4 rounded-lg hover:bg-muted transition-colors"
                  onClick={() => setIsMenuOpen(false)}
                >
                  👤 লগইন/রেজিস্টার
                </Link>
              )}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};

export default Header;
