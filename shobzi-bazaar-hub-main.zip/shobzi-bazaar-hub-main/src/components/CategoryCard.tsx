import { motion } from 'framer-motion';
import { Category } from '@/types';

interface CategoryCardProps {
  category: Category;
  onClick: (categoryId: string) => void;
}

const CategoryCard = ({ category, onClick }: CategoryCardProps) => {
  return (
    <motion.div
      whileHover={{ scale: 1.05, y: -5 }}
      whileTap={{ scale: 0.95 }}
      onClick={() => onClick(category.id)}
      className="cursor-pointer group"
    >
      <div className="card-product p-3 sm:p-4 text-center">
        <div className="relative w-16 h-16 sm:w-20 sm:h-20 mx-auto mb-2 sm:mb-3 rounded-full overflow-hidden bg-accent">
          <img
            src={category.image}
            alt={category.name}
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
          />
        </div>
        <h3 className="font-semibold text-sm sm:text-base font-bengali text-foreground">
          {category.nameBn}
        </h3>
        <p className="text-xs text-muted-foreground">{category.name}</p>
      </div>
    </motion.div>
  );
};

export default CategoryCard;
