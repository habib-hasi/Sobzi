import { useState, useRef } from 'react';
import { motion } from 'framer-motion';
import { 
  Clock, CheckCircle, XCircle, Truck, Package, RefreshCw, Search, Printer, Eye
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { updateOrderStatus, updateOrderPaymentStatus } from '@/services/firebaseService';
import { Order } from '@/types';
import { toast } from 'sonner';

interface OrderManagementProps {
  orders: Order[];
  loading: boolean;
  onRefresh: () => void;
}

const statusConfig = {
  pending: { label: 'পেন্ডিং', icon: Clock, color: 'bg-warning/20 text-warning' },
  confirmed: { label: 'কনফার্মড', icon: CheckCircle, color: 'bg-info/20 text-info' },
  processing: { label: 'প্রসেসিং', icon: Package, color: 'bg-primary/20 text-primary' },
  delivered: { label: 'ডেলিভারড', icon: Truck, color: 'bg-success/20 text-success' },
  cancelled: { label: 'বাতিল', icon: XCircle, color: 'bg-destructive/20 text-destructive' },
};

const OrderManagement = ({ orders, loading, onRefresh }: OrderManagementProps) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const invoiceRef = useRef<HTMLDivElement>(null);

  const filteredOrders = orders.filter(o => {
    const matchesStatus = filterStatus === 'all' || o.status === filterStatus;
    const matchesSearch = !searchQuery || 
      o.customerName?.toLowerCase().includes(searchQuery.toLowerCase()) ||
      o.phone?.includes(searchQuery) ||
      o.id.includes(searchQuery);
    return matchesStatus && matchesSearch;
  });

  const handleStatusChange = async (orderId: string, newStatus: Order['status']) => {
    try {
      await updateOrderStatus(orderId, newStatus);
      toast.success('স্ট্যাটাস আপডেট হয়েছে');
      onRefresh();
    } catch (error) {
      toast.error('স্ট্যাটাস আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handlePaymentToggle = async (order: Order) => {
    const newStatus = order.paymentStatus === 'paid' ? 'unpaid' : 'paid';
    try {
      await updateOrderPaymentStatus(order.id, newStatus);
      toast.success('পেমেন্ট স্ট্যাটাস আপডেট হয়েছে');
      onRefresh();
    } catch (error) {
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handlePrint = (order: Order) => {
    setSelectedOrder(order);
    setTimeout(() => {
      const printContent = invoiceRef.current;
      if (printContent) {
        const win = window.open('', '', 'width=400,height=600');
        if (win) {
          win.document.write(`
            <html><head><title>Invoice #${order.id.slice(0, 8).toUpperCase()}</title>
            <style>
              body { font-family: 'Hind Siliguri', sans-serif; padding: 20px; font-size: 14px; }
              table { width: 100%; border-collapse: collapse; margin: 10px 0; }
              th, td { border-bottom: 1px solid #ddd; padding: 6px 4px; text-align: left; }
              .total { font-size: 18px; font-weight: bold; }
              .header { text-align: center; margin-bottom: 20px; }
              .footer { text-align: center; margin-top: 20px; font-size: 12px; color: #666; }
            </style></head><body>
            ${printContent.innerHTML}
            </body></html>
          `);
          win.document.close();
          win.print();
        }
      }
    }, 100);
  };

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="নাম, ফোন বা আইডি দিয়ে খুঁজুন..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="pl-9" />
        </div>
        <Select value={filterStatus} onValueChange={setFilterStatus}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="স্ট্যাটাস" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">সব অর্ডার</SelectItem>
            {Object.entries(statusConfig).map(([key, config]) => (
              <SelectItem key={key} value={key}>{config.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button variant="outline" size="sm" onClick={onRefresh} disabled={loading}>
          <RefreshCw className={`h-4 w-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          রিফ্রেশ
        </Button>
      </div>

      {/* Orders List */}
      <div className="space-y-3">
        {filteredOrders.map((order, index) => {
          const status = statusConfig[order.status];
          const StatusIcon = status.icon;

          return (
            <motion.div
              key={order.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.02 }}
              className="bg-card rounded-xl border shadow-sm p-4"
            >
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                <div>
                  <p className="font-mono text-sm font-medium">#{order.id.slice(0, 8).toUpperCase()}</p>
                  <p className="text-xs text-muted-foreground">
                    {order.createdAt?.toLocaleDateString('bn-BD')} {order.createdAt?.toLocaleTimeString('bn-BD')}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Select value={order.status} onValueChange={v => handleStatusChange(order.id, v as Order['status'])}>
                    <SelectTrigger className={`w-36 h-8 text-xs ${status.color}`}>
                      <StatusIcon className="h-3 w-3 mr-1" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(statusConfig).map(([key, c]) => (
                        <SelectItem key={key} value={key}>{c.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid sm:grid-cols-3 gap-3 mb-3 text-sm">
                <div>
                  <p className="text-muted-foreground text-xs">গ্রাহক</p>
                  <p className="font-medium">{order.customerName || 'N/A'}</p>
                  <p className="text-muted-foreground">{order.phone}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">ঠিকানা</p>
                  <p className="text-sm">{order.address}</p>
                </div>
                <div>
                  <p className="text-muted-foreground text-xs">পেমেন্ট</p>
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{order.paymentMethod === 'cod' ? 'ক্যাশ অন ডেলিভারি' : order.paymentMethod}</span>
                    <button onClick={() => handlePaymentToggle(order)} className={`px-2 py-0.5 rounded text-xs cursor-pointer ${
                      order.paymentStatus === 'paid' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'
                    }`}>
                      {order.paymentStatus === 'paid' ? '✓ পেইড' : 'আনপেইড'}
                    </button>
                  </div>
                </div>
              </div>

              <div className="border-t pt-3 flex flex-wrap items-center justify-between gap-2">
                <div className="flex flex-wrap gap-1.5">
                  {order.items.map(item => (
                    <span key={item.id} className="text-xs bg-muted px-2 py-0.5 rounded">
                      {item.nameBn} ×{item.quantity}
                    </span>
                  ))}
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-lg font-bold text-primary">৳{order.total}</span>
                  <Button variant="ghost" size="sm" onClick={() => handlePrint(order)}>
                    <Printer className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </motion.div>
          );
        })}
        {filteredOrders.length === 0 && (
          <div className="text-center py-12 text-muted-foreground">
            <Package className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>কোনো অর্ডার পাওয়া যায়নি</p>
          </div>
        )}
      </div>

      {/* Hidden Invoice Template for Print */}
      {selectedOrder && (
        <div className="hidden">
          <div ref={invoiceRef}>
            <div className="header">
              <h2>🥬 সবজি বাজার</h2>
              <p>ইনভয়েস</p>
            </div>
            <p><strong>অর্ডার আইডি:</strong> #{selectedOrder.id.slice(0, 8).toUpperCase()}</p>
            <p><strong>তারিখ:</strong> {selectedOrder.createdAt?.toLocaleDateString('bn-BD')}</p>
            <p><strong>গ্রাহক:</strong> {selectedOrder.customerName}</p>
            <p><strong>ফোন:</strong> {selectedOrder.phone}</p>
            <p><strong>ঠিকানা:</strong> {selectedOrder.address}</p>
            <table>
              <thead><tr><th>পণ্য</th><th>পরিমাণ</th><th>দাম</th><th>মোট</th></tr></thead>
              <tbody>
                {selectedOrder.items.map(item => (
                  <tr key={item.id}>
                    <td>{item.nameBn}</td>
                    <td>{item.quantity}</td>
                    <td>৳{item.price}</td>
                    <td>৳{item.price * item.quantity}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p><strong>সাবটোটাল:</strong> ৳{selectedOrder.subtotal || selectedOrder.total}</p>
            <p><strong>ডেলিভারি:</strong> ৳{selectedOrder.deliveryCharge || 0}</p>
            {selectedOrder.couponDiscount && <p><strong>কুপন ছাড়:</strong> -৳{selectedOrder.couponDiscount}</p>}
            <p className="total"><strong>সর্বমোট: ৳{selectedOrder.total}</strong></p>
            <p><strong>পেমেন্ট:</strong> {selectedOrder.paymentMethod === 'cod' ? 'ক্যাশ অন ডেলিভারি' : selectedOrder.paymentMethod}</p>
            <div className="footer">
              <p>ধন্যবাদ! আবার কিনুন সবজি বাজার থেকে।</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default OrderManagement;
