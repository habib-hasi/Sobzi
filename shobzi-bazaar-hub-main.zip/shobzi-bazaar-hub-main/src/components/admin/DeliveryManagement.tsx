import { useState, useEffect } from 'react';
import { Plus, Trash2, Save, MapPin } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { getDeliverySettings, saveDeliverySettings } from '@/services/firebaseService';
import { DeliverySettings, DeliveryArea } from '@/types';
import { toast } from 'sonner';

const DeliveryManagement = () => {
  const [settings, setSettings] = useState<DeliverySettings>({
    defaultCharge: 50,
    freeDeliveryMinOrder: 500,
    areas: [],
    deliveryManName: '',
    deliveryManPhone: '',
    courierName: '',
    estimatedTime: '২-৪ ঘন্টা',
  });
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const s = await getDeliverySettings();
        setSettings(s);
      } catch (error) {
        console.error('Error:', error);
      }
      setLoading(false);
    };
    fetch();
  }, []);

  const addArea = () => {
    const newArea: DeliveryArea = {
      id: Date.now().toString(),
      name: '',
      nameBn: '',
      charge: settings.defaultCharge,
      isActive: true,
    };
    setSettings({ ...settings, areas: [...settings.areas, newArea] });
  };

  const updateArea = (id: string, updates: Partial<DeliveryArea>) => {
    setSettings({
      ...settings,
      areas: settings.areas.map(a => a.id === id ? { ...a, ...updates } : a),
    });
  };

  const removeArea = (id: string) => {
    setSettings({ ...settings, areas: settings.areas.filter(a => a.id !== id) });
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await saveDeliverySettings(settings);
      toast.success('ডেলিভারি সেটিংস সেভ হয়েছে');
    } catch (error) {
      toast.error('সেভ করতে সমস্যা হয়েছে');
    }
    setSaving(false);
  };

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-6">
      {/* General Settings */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <h3 className="font-bold font-bengali text-foreground mb-4">সাধারণ ডেলিভারি সেটিংস</h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <Label className="font-bengali">ডিফল্ট ডেলিভারি চার্জ (৳)</Label>
            <Input type="number" value={settings.defaultCharge} onChange={e => setSettings({...settings, defaultCharge: Number(e.target.value)})} />
          </div>
          <div>
            <Label className="font-bengali">ফ্রি ডেলিভারি মিনিমাম (৳)</Label>
            <Input type="number" value={settings.freeDeliveryMinOrder} onChange={e => setSettings({...settings, freeDeliveryMinOrder: Number(e.target.value)})} />
          </div>
          <div>
            <Label className="font-bengali">আনুমানিক ডেলিভারি সময়</Label>
            <Input value={settings.estimatedTime || ''} onChange={e => setSettings({...settings, estimatedTime: e.target.value})} placeholder="২-৪ ঘন্টা" />
          </div>
        </div>
      </div>

      {/* Delivery Person / Courier */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <h3 className="font-bold font-bengali text-foreground mb-4">ডেলিভারি ম্যান / কুরিয়ার</h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <Label className="font-bengali">ডেলিভারি ম্যানের নাম</Label>
            <Input value={settings.deliveryManName || ''} onChange={e => setSettings({...settings, deliveryManName: e.target.value})} />
          </div>
          <div>
            <Label className="font-bengali">ডেলিভারি ম্যানের ফোন</Label>
            <Input value={settings.deliveryManPhone || ''} onChange={e => setSettings({...settings, deliveryManPhone: e.target.value})} />
          </div>
          <div>
            <Label className="font-bengali">কুরিয়ার সার্ভিস</Label>
            <Input value={settings.courierName || ''} onChange={e => setSettings({...settings, courierName: e.target.value})} placeholder="যেমন: পাঠাও, রেডএক্স" />
          </div>
        </div>
      </div>

      {/* Area-based Charges */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold font-bengali text-foreground flex items-center gap-2">
            <MapPin className="h-4 w-4" />
            এলাকা অনুযায়ী চার্জ
          </h3>
          <Button variant="outline" size="sm" onClick={addArea}>
            <Plus className="h-4 w-4 mr-2" />
            এলাকা যোগ
          </Button>
        </div>

        {settings.areas.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-4">কোনো এলাকা যোগ করা হয়নি। সব জায়গায় ডিফল্ট চার্জ প্রযোজ্য হবে।</p>
        ) : (
          <div className="space-y-3">
            {settings.areas.map(area => (
              <div key={area.id} className="flex flex-wrap items-center gap-3 p-3 bg-muted/50 rounded-lg">
                <Input className="flex-1 min-w-[120px]" placeholder="এলাকার নাম (বাংলা)" value={area.nameBn} onChange={e => updateArea(area.id, { nameBn: e.target.value })} />
                <Input className="flex-1 min-w-[120px]" placeholder="Area Name" value={area.name} onChange={e => updateArea(area.id, { name: e.target.value })} />
                <div className="flex items-center gap-2 w-28">
                  <span className="text-sm">৳</span>
                  <Input type="number" value={area.charge} onChange={e => updateArea(area.id, { charge: Number(e.target.value) })} />
                </div>
                <Switch checked={area.isActive} onCheckedChange={v => updateArea(area.id, { isActive: v })} />
                <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => removeArea(area.id)}>
                  <Trash2 className="h-3.5 w-3.5" />
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      <Button onClick={handleSave} disabled={saving} className="btn-primary">
        <Save className="h-4 w-4 mr-2" />
        {saving ? 'সেভ হচ্ছে...' : 'সেটিংস সেভ করুন'}
      </Button>
    </div>
  );
};

export default DeliveryManagement;
