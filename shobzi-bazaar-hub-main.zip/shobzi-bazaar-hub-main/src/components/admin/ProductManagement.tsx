import { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Edit, Trash2, Search, Upload, X, Save, ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { categories } from '@/data/products';
import { addProduct, updateProduct, deleteProduct } from '@/services/firebaseService';
import { uploadToImgBB } from '@/services/imgbbService';
import { Product } from '@/types';
import { toast } from 'sonner';

interface ProductManagementProps {
  products: Product[];
  onRefresh: () => void;
}

const emptyProduct = {
  name: '', nameBn: '', price: 0, originalPrice: undefined as number | undefined,
  unit: '1 kg', image: '', category: 'vegetables', description: '', descriptionBn: '',
  inStock: true, discount: undefined as number | undefined, stockQuantity: 100, isActive: true,
};

const ProductManagement = ({ products, onRefresh }: ProductManagementProps) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [form, setForm] = useState(emptyProduct);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState('');
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState<string | null>(null);

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    p.nameBn.includes(searchQuery)
  );

  const openAddDialog = () => {
    setEditingProduct(null);
    setForm(emptyProduct);
    setImageFile(null);
    setImagePreview('');
    setIsDialogOpen(true);
  };

  const openEditDialog = (product: Product) => {
    setEditingProduct(product);
    setForm({
      name: product.name,
      nameBn: product.nameBn,
      price: product.price,
      originalPrice: product.originalPrice,
      unit: product.unit,
      image: product.image,
      category: product.category,
      description: product.description || '',
      descriptionBn: product.descriptionBn || '',
      inStock: product.inStock,
      discount: product.discount,
      stockQuantity: product.stockQuantity || 0,
      isActive: product.isActive !== false,
    });
    setImagePreview(product.image);
    setImageFile(null);
    setIsDialogOpen(true);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    if (!form.nameBn || !form.name || !form.price) {
      toast.error('পণ্যের নাম এবং দাম দিতে হবে');
      return;
    }

    setSaving(true);
    try {
      let imageUrl = form.image;
      
      if (imageFile) {
        toast.info('ছবি আপলোড হচ্ছে...');
        imageUrl = await uploadToImgBB(imageFile);
      }

      if (!imageUrl && !editingProduct) {
        toast.error('পণ্যের ছবি দিতে হবে');
        setSaving(false);
        return;
      }

      const productData = {
        name: form.name,
        nameBn: form.nameBn,
        price: Number(form.price),
        originalPrice: form.originalPrice ? Number(form.originalPrice) : undefined,
        unit: form.unit,
        image: imageUrl,
        category: form.category,
        description: form.description,
        descriptionBn: form.descriptionBn,
        inStock: form.inStock,
        discount: form.discount ? Number(form.discount) : undefined,
        stockQuantity: Number(form.stockQuantity),
        isActive: form.isActive,
      };

      if (editingProduct) {
        await updateProduct(editingProduct.id, productData);
        toast.success('পণ্য আপডেট হয়েছে');
      } else {
        await addProduct(productData);
        toast.success('নতুন পণ্য যোগ হয়েছে');
      }

      setIsDialogOpen(false);
      onRefresh();
    } catch (error) {
      console.error('Error saving product:', error);
      toast.error('পণ্য সেভ করতে সমস্যা হয়েছে');
    }
    setSaving(false);
  };

  const handleDelete = async (productId: string) => {
    if (!confirm('এই পণ্যটি মুছে ফেলতে চান?')) return;
    setDeleting(productId);
    try {
      await deleteProduct(productId);
      toast.success('পণ্য মুছে ফেলা হয়েছে');
      onRefresh();
    } catch (error) {
      toast.error('পণ্য মুছতে সমস্যা হয়েছে');
    }
    setDeleting(null);
  };

  const handleToggleActive = async (product: Product) => {
    try {
      await updateProduct(product.id, { isActive: !product.isActive });
      toast.success(product.isActive ? 'পণ্য নিষ্ক্রিয় করা হয়েছে' : 'পণ্য সক্রিয় করা হয়েছে');
      onRefresh();
    } catch (error) {
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  const handleToggleStock = async (product: Product) => {
    try {
      await updateProduct(product.id, { inStock: !product.inStock });
      toast.success(product.inStock ? 'স্টক আউট করা হয়েছে' : 'স্টক ইন করা হয়েছে');
      onRefresh();
    } catch (error) {
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            placeholder="পণ্য খুঁজুন..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Button onClick={openAddDialog} className="btn-primary">
          <Plus className="mr-2 h-4 w-4" />
          নতুন পণ্য
        </Button>
      </div>

      {/* Table */}
      <div className="bg-card rounded-xl border shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-16">ছবি</TableHead>
                <TableHead>পণ্য</TableHead>
                <TableHead>ক্যাটাগরি</TableHead>
                <TableHead>দাম</TableHead>
                <TableHead>স্টক</TableHead>
                <TableHead>সক্রিয়</TableHead>
                <TableHead className="w-24">অ্যাকশন</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredProducts.map(product => (
                <TableRow key={product.id} className={product.isActive === false ? 'opacity-50' : ''}>
                  <TableCell>
                    <img src={product.image} alt={product.name} className="w-12 h-12 rounded-lg object-cover" />
                  </TableCell>
                  <TableCell>
                    <p className="font-semibold font-bengali text-sm">{product.nameBn}</p>
                    <p className="text-xs text-muted-foreground">{product.name}</p>
                  </TableCell>
                  <TableCell className="text-sm capitalize">{product.category}</TableCell>
                  <TableCell>
                    <span className="font-semibold">৳{product.price}</span>
                    {product.originalPrice && (
                      <span className="text-xs text-muted-foreground line-through ml-1">৳{product.originalPrice}</span>
                    )}
                  </TableCell>
                  <TableCell>
                    <button onClick={() => handleToggleStock(product)}>
                      <span className={`px-2 py-0.5 rounded-full text-xs cursor-pointer ${
                        product.inStock ? 'bg-success/20 text-success' : 'bg-destructive/20 text-destructive'
                      }`}>
                        {product.inStock ? 'ইন স্টক' : 'আউট'}
                      </span>
                    </button>
                  </TableCell>
                  <TableCell>
                    <Switch
                      checked={product.isActive !== false}
                      onCheckedChange={() => handleToggleActive(product)}
                    />
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditDialog(product)}>
                        <Edit className="h-3.5 w-3.5" />
                      </Button>
                      <Button 
                        variant="ghost" size="icon" 
                        className="h-8 w-8 text-destructive" 
                        onClick={() => handleDelete(product.id)}
                        disabled={deleting === product.id}
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
              {filteredProducts.length === 0 && (
                <TableRow>
                  <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                    কোনো পণ্য পাওয়া যায়নি
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[550px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-bengali">
              {editingProduct ? 'পণ্য সম্পাদনা' : 'নতুন পণ্য যোগ করুন'}
            </DialogTitle>
            <DialogDescription>পণ্যের বিস্তারিত তথ্য দিন</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4 py-2">
            {/* Image Upload */}
            <div>
              <Label className="font-bengali">পণ্যের ছবি *</Label>
              <div className="mt-2 flex items-center gap-4">
                {imagePreview ? (
                  <div className="relative w-24 h-24 rounded-lg overflow-hidden border">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    <button
                      onClick={() => { setImageFile(null); setImagePreview(''); setForm({...form, image: ''}); }}
                      className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-0.5"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <label className="w-24 h-24 rounded-lg border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-primary transition-colors">
                    <ImageIcon className="h-6 w-6 text-muted-foreground mb-1" />
                    <span className="text-xs text-muted-foreground">আপলোড</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
                  </label>
                )}
                {!imagePreview && (
                  <label className="cursor-pointer">
                    <Button variant="outline" size="sm" asChild>
                      <span><Upload className="h-4 w-4 mr-2" /> ছবি বাছাই</span>
                    </Button>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
                  </label>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="font-bengali">পণ্যের নাম (বাংলা) *</Label>
                <Input value={form.nameBn} onChange={e => setForm({...form, nameBn: e.target.value})} placeholder="তাজা আলু" />
              </div>
              <div>
                <Label>Product Name (English) *</Label>
                <Input value={form.name} onChange={e => setForm({...form, name: e.target.value})} placeholder="Fresh Potato" />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="font-bengali">দাম (৳) *</Label>
                <Input type="number" value={form.price || ''} onChange={e => setForm({...form, price: Number(e.target.value)})} />
              </div>
              <div>
                <Label className="font-bengali">আগের দাম</Label>
                <Input type="number" value={form.originalPrice || ''} onChange={e => setForm({...form, originalPrice: Number(e.target.value) || undefined})} />
              </div>
              <div>
                <Label className="font-bengali">ডিসকাউন্ট %</Label>
                <Input type="number" value={form.discount || ''} onChange={e => setForm({...form, discount: Number(e.target.value) || undefined})} />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <Label className="font-bengali">একক</Label>
                <Select value={form.unit} onValueChange={v => setForm({...form, unit: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1 kg">১ কেজি</SelectItem>
                    <SelectItem value="500 gm">৫০০ গ্রাম</SelectItem>
                    <SelectItem value="250 gm">২৫০ গ্রাম</SelectItem>
                    <SelectItem value="200 gm">২০০ গ্রাম</SelectItem>
                    <SelectItem value="100 gm">১০০ গ্রাম</SelectItem>
                    <SelectItem value="1 ltr">১ লিটার</SelectItem>
                    <SelectItem value="500 ml">৫০০ মিলি</SelectItem>
                    <SelectItem value="1 pc">১ পিস</SelectItem>
                    <SelectItem value="1 dozen">১ ডজন</SelectItem>
                    <SelectItem value="1 pair">১ জোড়া</SelectItem>
                    <SelectItem value="1 pack">১ প্যাকেট</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="font-bengali">ক্যাটাগরি</Label>
                <Select value={form.category} onValueChange={v => setForm({...form, category: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat.id} value={cat.id}>{cat.icon} {cat.nameBn}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="font-bengali">স্টক সংখ্যা</Label>
                <Input type="number" value={form.stockQuantity || ''} onChange={e => setForm({...form, stockQuantity: Number(e.target.value)})} />
              </div>
            </div>

            <div>
              <Label className="font-bengali">বিবরণ (বাংলা)</Label>
              <Textarea value={form.descriptionBn} onChange={e => setForm({...form, descriptionBn: e.target.value})} rows={2} />
            </div>

            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={form.inStock} onCheckedChange={v => setForm({...form, inStock: v})} />
                <Label className="font-bengali">স্টকে আছে</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.isActive} onCheckedChange={v => setForm({...form, isActive: v})} />
                <Label className="font-bengali">সক্রিয়</Label>
              </div>
            </div>

            <Button onClick={handleSave} disabled={saving} className="btn-primary mt-2">
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'সেভ হচ্ছে...' : editingProduct ? 'আপডেট করুন' : 'পণ্য যোগ করুন'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default ProductManagement;
