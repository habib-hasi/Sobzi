import { useState, useEffect } from 'react';
import { Save, Upload, X, Store, ImageIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { getSiteSettings, saveSiteSettings } from '@/services/firebaseService';
import { uploadToImgBB } from '@/services/imgbbService';
import { SiteSettings } from '@/types';
import { toast } from 'sonner';

const SiteSettingsPanel = () => {
  const [settings, setSettings] = useState<SiteSettings>({
    storeName: 'Sobji Bazar',
    storeNameBn: 'সবজি বাজার',
    phone: '',
    email: '',
    address: '',
    addressBn: '',
    deliveryTime: '২-৪ ঘন্টা',
    openTime: '08:00',
    closeTime: '22:00',
    isOpen: true,
    facebookUrl: '',
    instagramUrl: '',
    whatsappNumber: '',
  });
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [logoFile, setLogoFile] = useState<File | null>(null);
  const [logoPreview, setLogoPreview] = useState('');

  useEffect(() => {
    const fetch = async () => {
      try {
        const s = await getSiteSettings();
        setSettings(s);
        if (s.logo) setLogoPreview(s.logo);
      } catch (error) {
        console.error('Error:', error);
      }
      setLoading(false);
    };
    fetch();
  }, []);

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setLogoFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setLogoPreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      let logoUrl = settings.logo;
      if (logoFile) {
        toast.info('লোগো আপলোড হচ্ছে...');
        logoUrl = await uploadToImgBB(logoFile);
      }
      await saveSiteSettings({ ...settings, logo: logoUrl });
      toast.success('সেটিংস সেভ হয়েছে');
    } catch (error) {
      toast.error('সেভ করতে সমস্যা হয়েছে');
    }
    setSaving(false);
  };

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-6">
      {/* Store Info */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <h3 className="font-bold font-bengali text-foreground mb-4 flex items-center gap-2">
          <Store className="h-4 w-4" />
          দোকানের তথ্য
        </h3>
        <div className="grid sm:grid-cols-2 gap-4">
          <div>
            <Label className="font-bengali">দোকানের নাম (বাংলা)</Label>
            <Input value={settings.storeNameBn} onChange={e => setSettings({...settings, storeNameBn: e.target.value})} />
          </div>
          <div>
            <Label>Store Name (English)</Label>
            <Input value={settings.storeName} onChange={e => setSettings({...settings, storeName: e.target.value})} />
          </div>
          <div>
            <Label className="font-bengali">ফোন নম্বর</Label>
            <Input value={settings.phone} onChange={e => setSettings({...settings, phone: e.target.value})} />
          </div>
          <div>
            <Label>Email</Label>
            <Input value={settings.email || ''} onChange={e => setSettings({...settings, email: e.target.value})} />
          </div>
          <div className="sm:col-span-2">
            <Label className="font-bengali">ঠিকানা</Label>
            <Textarea value={settings.addressBn || settings.address} onChange={e => setSettings({...settings, addressBn: e.target.value, address: e.target.value})} rows={2} />
          </div>
        </div>
      </div>

      {/* Logo */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <h3 className="font-bold font-bengali text-foreground mb-4">লোগো</h3>
        <div className="flex items-center gap-4">
          {logoPreview ? (
            <div className="relative w-20 h-20 rounded-lg overflow-hidden border">
              <img src={logoPreview} alt="Logo" className="w-full h-full object-contain" />
              <button onClick={() => { setLogoFile(null); setLogoPreview(''); setSettings({...settings, logo: ''}); }}
                className="absolute top-1 right-1 bg-destructive text-destructive-foreground rounded-full p-0.5">
                <X className="h-3 w-3" />
              </button>
            </div>
          ) : (
            <label className="w-20 h-20 rounded-lg border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-primary">
              <ImageIcon className="h-6 w-6 text-muted-foreground" />
              <input type="file" accept="image/*" className="hidden" onChange={handleLogoChange} />
            </label>
          )}
          <label className="cursor-pointer">
            <Button variant="outline" size="sm" asChild>
              <span><Upload className="h-4 w-4 mr-2" /> লোগো আপলোড</span>
            </Button>
            <input type="file" accept="image/*" className="hidden" onChange={handleLogoChange} />
          </label>
        </div>
      </div>

      {/* Timing */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <h3 className="font-bold font-bengali text-foreground mb-4">সময়সূচি</h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <Label className="font-bengali">ডেলিভারি সময়</Label>
            <Input value={settings.deliveryTime} onChange={e => setSettings({...settings, deliveryTime: e.target.value})} placeholder="২-৪ ঘন্টা" />
          </div>
          <div>
            <Label className="font-bengali">ওপেন টাইম</Label>
            <Input type="time" value={settings.openTime} onChange={e => setSettings({...settings, openTime: e.target.value})} />
          </div>
          <div>
            <Label className="font-bengali">ক্লোজ টাইম</Label>
            <Input type="time" value={settings.closeTime} onChange={e => setSettings({...settings, closeTime: e.target.value})} />
          </div>
        </div>
        <div className="mt-4 flex items-center gap-3">
          <Switch checked={settings.isOpen} onCheckedChange={v => setSettings({...settings, isOpen: v})} />
          <Label className="font-bengali">{settings.isOpen ? '🟢 দোকান খোলা আছে' : '🔴 দোকান বন্ধ'}</Label>
        </div>
      </div>

      {/* Social Media */}
      <div className="bg-card rounded-xl border shadow-sm p-5">
        <h3 className="font-bold font-bengali text-foreground mb-4">সোশ্যাল মিডিয়া</h3>
        <div className="grid sm:grid-cols-3 gap-4">
          <div>
            <Label>Facebook URL</Label>
            <Input value={settings.facebookUrl || ''} onChange={e => setSettings({...settings, facebookUrl: e.target.value})} placeholder="https://facebook.com/..." />
          </div>
          <div>
            <Label>Instagram URL</Label>
            <Input value={settings.instagramUrl || ''} onChange={e => setSettings({...settings, instagramUrl: e.target.value})} placeholder="https://instagram.com/..." />
          </div>
          <div>
            <Label>WhatsApp Number</Label>
            <Input value={settings.whatsappNumber || ''} onChange={e => setSettings({...settings, whatsappNumber: e.target.value})} placeholder="880170..." />
          </div>
        </div>
      </div>

      <Button onClick={handleSave} disabled={saving} className="btn-primary">
        <Save className="h-4 w-4 mr-2" />
        {saving ? 'সেভ হচ্ছে...' : 'সেটিংস সেভ করুন'}
      </Button>
    </div>
  );
};

export default SiteSettingsPanel;
