import { useState, useEffect } from 'react';
import { Plus, Trash2, Edit, Image as ImageIcon, Upload, X, Save, ArrowUp, ArrowDown } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { getBanners, addBanner, updateBanner, deleteBanner } from '@/services/firebaseService';
import { uploadToImgBB } from '@/services/imgbbService';
import { Banner } from '@/types';
import { toast } from 'sonner';

const BannerManagement = () => {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingBanner, setEditingBanner] = useState<Banner | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState('');
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    title: '', titleBn: '', subtitle: '', subtitleBn: '',
    image: '', link: '', type: 'hero' as Banner['type'],
    isActive: true, order: 0, buttonText: '', buttonTextBn: '',
  });

  const fetchBanners = async () => {
    try {
      const data = await getBanners();
      setBanners(data);
    } catch (error) {
      console.error('Error:', error);
    }
    setLoading(false);
  };

  useEffect(() => { fetchBanners(); }, []);

  const openAddDialog = () => {
    setEditingBanner(null);
    setForm({ title: '', titleBn: '', subtitle: '', subtitleBn: '', image: '', link: '', type: 'hero', isActive: true, order: banners.length, buttonText: '', buttonTextBn: '' });
    setImageFile(null); setImagePreview('');
    setIsDialogOpen(true);
  };

  const openEditDialog = (banner: Banner) => {
    setEditingBanner(banner);
    setForm({
      title: banner.title, titleBn: banner.titleBn,
      subtitle: banner.subtitle || '', subtitleBn: banner.subtitleBn || '',
      image: banner.image, link: banner.link || '',
      type: banner.type, isActive: banner.isActive,
      order: banner.order, buttonText: banner.buttonText || '',
      buttonTextBn: banner.buttonTextBn || '',
    });
    setImagePreview(banner.image);
    setImageFile(null);
    setIsDialogOpen(true);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => setImagePreview(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSave = async () => {
    if (!form.titleBn) { toast.error('ব্যানার শিরোনাম দিতে হবে'); return; }
    setSaving(true);
    try {
      let imageUrl = form.image;
      if (imageFile) {
        toast.info('ছবি আপলোড হচ্ছে...');
        imageUrl = await uploadToImgBB(imageFile);
      }
      if (!imageUrl && !editingBanner) { toast.error('ছবি আপলোড করুন'); setSaving(false); return; }

      const data = { ...form, image: imageUrl };
      if (editingBanner) {
        await updateBanner(editingBanner.id, data);
        toast.success('ব্যানার আপডেট হয়েছে');
      } else {
        await addBanner(data);
        toast.success('নতুন ব্যানার যোগ হয়েছে');
      }
      setIsDialogOpen(false);
      fetchBanners();
    } catch (error) {
      toast.error('সেভ করতে সমস্যা হয়েছে');
    }
    setSaving(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('এই ব্যানারটি মুছে ফেলতে চান?')) return;
    try { await deleteBanner(id); toast.success('মুছে ফেলা হয়েছে'); fetchBanners(); }
    catch { toast.error('মুছতে সমস্যা হয়েছে'); }
  };

  const typeLabels = { hero: 'হোমপেজ', offer: 'অফার', festival: 'উৎসব' };

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold font-bengali text-foreground">ব্যানার ও স্লাইডার</h3>
        <Button onClick={openAddDialog} className="btn-primary">
          <Plus className="h-4 w-4 mr-2" /> নতুন ব্যানার
        </Button>
      </div>

      <div className="grid sm:grid-cols-2 gap-4">
        {banners.map(banner => (
          <div key={banner.id} className={`bg-card rounded-xl border shadow-sm overflow-hidden ${!banner.isActive ? 'opacity-50' : ''}`}>
            <div className="relative h-36">
              <img src={banner.image} alt={banner.title} className="w-full h-full object-cover" />
              <span className="absolute top-2 left-2 px-2 py-0.5 rounded bg-foreground/70 text-card text-xs">
                {typeLabels[banner.type]}
              </span>
            </div>
            <div className="p-4">
              <h4 className="font-semibold font-bengali text-sm">{banner.titleBn}</h4>
              {banner.subtitleBn && <p className="text-xs text-muted-foreground">{banner.subtitleBn}</p>}
              <div className="flex items-center justify-between mt-3">
                <Switch checked={banner.isActive} onCheckedChange={async (v) => {
                  await updateBanner(banner.id, { isActive: v }); fetchBanners();
                }} />
                <div className="flex gap-1">
                  <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => openEditDialog(banner)}>
                    <Edit className="h-3.5 w-3.5" />
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-destructive" onClick={() => handleDelete(banner.id)}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          </div>
        ))}
        {banners.length === 0 && (
          <div className="col-span-2 text-center py-8 text-muted-foreground">
            <ImageIcon className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>কোনো ব্যানার যোগ করা হয়নি</p>
          </div>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[500px] max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="font-bengali">{editingBanner ? 'ব্যানার সম্পাদনা' : 'নতুন ব্যানার'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            {/* Image */}
            <div>
              <Label className="font-bengali">ব্যানার ছবি *</Label>
              <div className="mt-2">
                {imagePreview ? (
                  <div className="relative h-32 rounded-lg overflow-hidden border">
                    <img src={imagePreview} alt="Preview" className="w-full h-full object-cover" />
                    <button onClick={() => { setImageFile(null); setImagePreview(''); setForm({...form, image: ''}); }}
                      className="absolute top-2 right-2 bg-destructive text-destructive-foreground rounded-full p-1">
                      <X className="h-3 w-3" />
                    </button>
                  </div>
                ) : (
                  <label className="h-32 rounded-lg border-2 border-dashed flex flex-col items-center justify-center cursor-pointer hover:border-primary">
                    <Upload className="h-6 w-6 text-muted-foreground mb-1" />
                    <span className="text-xs text-muted-foreground">ছবি আপলোড করুন</span>
                    <input type="file" accept="image/*" className="hidden" onChange={handleImageChange} />
                  </label>
                )}
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="font-bengali">শিরোনাম (বাংলা) *</Label>
                <Input value={form.titleBn} onChange={e => setForm({...form, titleBn: e.target.value})} />
              </div>
              <div>
                <Label>Title (English)</Label>
                <Input value={form.title} onChange={e => setForm({...form, title: e.target.value})} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="font-bengali">সাবটাইটেল (বাংলা)</Label>
                <Input value={form.subtitleBn} onChange={e => setForm({...form, subtitleBn: e.target.value})} />
              </div>
              <div>
                <Label className="font-bengali">ব্যানার টাইপ</Label>
                <Select value={form.type} onValueChange={v => setForm({...form, type: v as any})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="hero">হোমপেজ ব্যানার</SelectItem>
                    <SelectItem value="offer">অফার ব্যানার</SelectItem>
                    <SelectItem value="festival">উৎসব ব্যানার</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="font-bengali">বাটন টেক্সট (বাংলা)</Label>
                <Input value={form.buttonTextBn} onChange={e => setForm({...form, buttonTextBn: e.target.value})} placeholder="এখনই কিনুন" />
              </div>
              <div>
                <Label>Link URL</Label>
                <Input value={form.link} onChange={e => setForm({...form, link: e.target.value})} placeholder="/" />
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={form.isActive} onCheckedChange={v => setForm({...form, isActive: v})} />
              <Label className="font-bengali">সক্রিয়</Label>
            </div>
            <Button onClick={handleSave} disabled={saving} className="btn-primary mt-2">
              <Save className="h-4 w-4 mr-2" />
              {saving ? 'সেভ হচ্ছে...' : editingBanner ? 'আপডেট করুন' : 'ব্যানার যোগ করুন'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default BannerManagement;
