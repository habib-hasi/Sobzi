import { useState, useEffect } from 'react';
import { Plus, Trash2, Edit, Tag, Save, Percent, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { getCoupons, addCoupon, updateCoupon, deleteCoupon } from '@/services/firebaseService';
import { Coupon } from '@/types';
import { toast } from 'sonner';

const OfferManagement = () => {
  const [coupons, setCoupons] = useState<Coupon[]>([]);
  const [loading, setLoading] = useState(true);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingCoupon, setEditingCoupon] = useState<Coupon | null>(null);
  const [form, setForm] = useState({
    code: '',
    discountType: 'percentage' as 'percentage' | 'fixed',
    discountValue: 0,
    minOrderAmount: 0,
    maxDiscount: undefined as number | undefined,
    isActive: true,
    freeDelivery: false,
  });

  const fetchCoupons = async () => {
    try {
      const data = await getCoupons();
      setCoupons(data);
    } catch (error) {
      console.error('Error:', error);
    }
    setLoading(false);
  };

  useEffect(() => { fetchCoupons(); }, []);

  const openAddDialog = () => {
    setEditingCoupon(null);
    setForm({
      code: '', discountType: 'percentage', discountValue: 0,
      minOrderAmount: 0, maxDiscount: undefined, isActive: true, freeDelivery: false,
    });
    setIsDialogOpen(true);
  };

  const openEditDialog = (coupon: Coupon) => {
    setEditingCoupon(coupon);
    setForm({
      code: coupon.code,
      discountType: coupon.discountType,
      discountValue: coupon.discountValue,
      minOrderAmount: coupon.minOrderAmount,
      maxDiscount: coupon.maxDiscount,
      isActive: coupon.isActive,
      freeDelivery: coupon.freeDelivery,
    });
    setIsDialogOpen(true);
  };

  const handleSave = async () => {
    if (!form.code || !form.discountValue) {
      toast.error('কুপন কোড ও ডিসকাউন্ট দিতে হবে');
      return;
    }
    try {
      const data = {
        ...form,
        code: form.code.toUpperCase(),
        usageCount: 0,
      };
      if (editingCoupon) {
        await updateCoupon(editingCoupon.id, data);
        toast.success('কুপন আপডেট হয়েছে');
      } else {
        await addCoupon(data);
        toast.success('নতুন কুপন যোগ হয়েছে');
      }
      setIsDialogOpen(false);
      fetchCoupons();
    } catch (error) {
      toast.error('সেভ করতে সমস্যা হয়েছে');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('এই কুপনটি মুছে ফেলতে চান?')) return;
    try {
      await deleteCoupon(id);
      toast.success('কুপন মুছে ফেলা হয়েছে');
      fetchCoupons();
    } catch (error) {
      toast.error('মুছতে সমস্যা হয়েছে');
    }
  };

  const handleToggle = async (coupon: Coupon) => {
    try {
      await updateCoupon(coupon.id, { isActive: !coupon.isActive });
      toast.success(coupon.isActive ? 'কুপন নিষ্ক্রিয় করা হয়েছে' : 'কুপন সক্রিয় করা হয়েছে');
      fetchCoupons();
    } catch (error) {
      toast.error('আপডেট করতে সমস্যা হয়েছে');
    }
  };

  if (loading) return <div className="text-center py-8 text-muted-foreground">লোড হচ্ছে...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-bold font-bengali text-foreground">অফার ও কুপন কোড</h3>
        <Button onClick={openAddDialog} className="btn-primary">
          <Plus className="h-4 w-4 mr-2" />
          নতুন কুপন
        </Button>
      </div>

      {/* Coupons List */}
      <div className="grid sm:grid-cols-2 gap-4">
        {coupons.map(coupon => (
          <div key={coupon.id} className={`bg-card rounded-xl border shadow-sm p-4 ${!coupon.isActive ? 'opacity-50' : ''}`}>
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-lg bg-secondary/20 flex items-center justify-center">
                  {coupon.freeDelivery ? <Gift className="h-5 w-5 text-secondary" /> : <Tag className="h-5 w-5 text-secondary" />}
                </div>
                <div>
                  <p className="font-mono font-bold text-foreground">{coupon.code}</p>
                  <p className="text-xs text-muted-foreground">
                    {coupon.discountType === 'percentage' ? `${coupon.discountValue}% ছাড়` : `৳${coupon.discountValue} ছাড়`}
                  </p>
                </div>
              </div>
              <Switch checked={coupon.isActive} onCheckedChange={() => handleToggle(coupon)} />
            </div>
            <div className="text-xs text-muted-foreground space-y-1 mb-3">
              {coupon.minOrderAmount > 0 && <p>🛒 মিনিমাম অর্ডার: ৳{coupon.minOrderAmount}</p>}
              {coupon.maxDiscount && <p>📊 সর্বোচ্চ ছাড়: ৳{coupon.maxDiscount}</p>}
              {coupon.freeDelivery && <p>🚚 ফ্রি ডেলিভারি</p>}
              <p>📈 ব্যবহার: {coupon.usageCount} বার</p>
            </div>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" onClick={() => openEditDialog(coupon)}>
                <Edit className="h-3.5 w-3.5 mr-1" /> সম্পাদনা
              </Button>
              <Button variant="ghost" size="sm" className="text-destructive" onClick={() => handleDelete(coupon.id)}>
                <Trash2 className="h-3.5 w-3.5 mr-1" /> মুছুন
              </Button>
            </div>
          </div>
        ))}
        {coupons.length === 0 && (
          <div className="col-span-2 text-center py-8 text-muted-foreground">
            <Tag className="h-12 w-12 mx-auto mb-3 opacity-50" />
            <p>কোনো কুপন যোগ করা হয়নি</p>
          </div>
        )}
      </div>

      {/* Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[450px]">
          <DialogHeader>
            <DialogTitle className="font-bengali">{editingCoupon ? 'কুপন সম্পাদনা' : 'নতুন কুপন'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-2">
            <div>
              <Label className="font-bengali">কুপন কোড *</Label>
              <Input value={form.code} onChange={e => setForm({...form, code: e.target.value.toUpperCase()})} placeholder="যেমন: SAVE20" className="font-mono uppercase" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="font-bengali">ডিসকাউন্ট টাইপ</Label>
                <Select value={form.discountType} onValueChange={v => setForm({...form, discountType: v as any})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="percentage">শতাংশ (%)</SelectItem>
                    <SelectItem value="fixed">নির্দিষ্ট (৳)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="font-bengali">ডিসকাউন্ট *</Label>
                <Input type="number" value={form.discountValue || ''} onChange={e => setForm({...form, discountValue: Number(e.target.value)})} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="font-bengali">মিনিমাম অর্ডার (৳)</Label>
                <Input type="number" value={form.minOrderAmount || ''} onChange={e => setForm({...form, minOrderAmount: Number(e.target.value)})} />
              </div>
              <div>
                <Label className="font-bengali">সর্বোচ্চ ছাড় (৳)</Label>
                <Input type="number" value={form.maxDiscount || ''} onChange={e => setForm({...form, maxDiscount: Number(e.target.value) || undefined})} />
              </div>
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={form.isActive} onCheckedChange={v => setForm({...form, isActive: v})} />
                <Label className="font-bengali">সক্রিয়</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.freeDelivery} onCheckedChange={v => setForm({...form, freeDelivery: v})} />
                <Label className="font-bengali">ফ্রি ডেলিভারি</Label>
              </div>
            </div>
            <Button onClick={handleSave} className="btn-primary mt-2">
              <Save className="h-4 w-4 mr-2" />
              {editingCoupon ? 'আপডেট করুন' : 'কুপন যোগ করুন'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default OfferManagement;
