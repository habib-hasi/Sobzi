import { 
  LayoutDashboard, Package, ShoppingCart, Truck, Tag, Image, Settings, LogOut, Home
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/context/AuthContext';

export type AdminTab = 'dashboard' | 'products' | 'orders' | 'delivery' | 'offers' | 'banners' | 'settings';

interface AdminSidebarProps {
  activeTab: AdminTab;
  onTabChange: (tab: AdminTab) => void;
  isMobileOpen?: boolean;
  onMobileClose?: () => void;
}

const menuItems: { id: AdminTab; label: string; icon: typeof LayoutDashboard }[] = [
  { id: 'dashboard', label: 'ড্যাশবোর্ড', icon: LayoutDashboard },
  { id: 'products', label: 'পণ্য ব্যবস্থাপনা', icon: Package },
  { id: 'orders', label: 'অর্ডার', icon: ShoppingCart },
  { id: 'delivery', label: 'ডেলিভারি', icon: Truck },
  { id: 'offers', label: 'অফার ও কুপন', icon: Tag },
  { id: 'banners', label: 'ব্যানার', icon: Image },
  { id: 'settings', label: 'সেটিংস', icon: Settings },
];

const AdminSidebar = ({ activeTab, onTabChange, isMobileOpen, onMobileClose }: AdminSidebarProps) => {
  const { logout } = useAuth();

  const handleTabClick = (tab: AdminTab) => {
    onTabChange(tab);
    onMobileClose?.();
  };

  return (
    <>
      {/* Mobile overlay */}
      {isMobileOpen && (
        <div className="fixed inset-0 bg-foreground/50 z-40 lg:hidden" onClick={onMobileClose} />
      )}
      
      <aside className={`
        fixed top-0 left-0 h-full w-64 bg-card border-r z-50 flex flex-col transition-transform duration-300
        lg:relative lg:translate-x-0
        ${isMobileOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Logo */}
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <span className="text-2xl">🥬</span>
            <div>
              <h1 className="font-bold font-bengali text-foreground">সবজি বাজার</h1>
              <span className="text-xs text-muted-foreground">অ্যাডমিন প্যানেল</span>
            </div>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
          {menuItems.map(item => (
            <button
              key={item.id}
              onClick={() => handleTabClick(item.id)}
              className={`
                w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors
                ${activeTab === item.id 
                  ? 'bg-primary text-primary-foreground' 
                  : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                }
              `}
            >
              <item.icon className="h-4 w-4" />
              <span className="font-bengali">{item.label}</span>
            </button>
          ))}
        </nav>

        {/* Bottom actions */}
        <div className="p-3 border-t space-y-1">
          <Link to="/" className="block">
            <Button variant="ghost" size="sm" className="w-full justify-start gap-3 text-muted-foreground">
              <Home className="h-4 w-4" />
              <span className="font-bengali">হোম পেজ</span>
            </Button>
          </Link>
          <Button 
            variant="ghost" 
            size="sm" 
            onClick={logout}
            className="w-full justify-start gap-3 text-destructive hover:text-destructive"
          >
            <LogOut className="h-4 w-4" />
            <span className="font-bengali">লগআউট</span>
          </Button>
        </div>
      </aside>
    </>
  );
};

export default AdminSidebar;
