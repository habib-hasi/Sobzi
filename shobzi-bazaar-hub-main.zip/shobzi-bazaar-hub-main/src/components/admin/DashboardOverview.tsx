import { motion } from 'framer-motion';
import { 
  Package, ShoppingCart, Clock, TrendingUp, Truck, CheckCircle, AlertTriangle, Star
} from 'lucide-react';
import { Order, Product } from '@/types';
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from '@/components/ui/table';

interface DashboardOverviewProps {
  orders: Order[];
  products: Product[];
}

const statusConfig = {
  pending: { label: 'পেন্ডিং', color: 'bg-warning/20 text-warning' },
  confirmed: { label: 'কনফার্মড', color: 'bg-info/20 text-info' },
  processing: { label: 'প্রসেসিং', color: 'bg-primary/20 text-primary' },
  delivered: { label: 'ডেলিভারড', color: 'bg-success/20 text-success' },
  cancelled: { label: 'বাতিল', color: 'bg-destructive/20 text-destructive' },
};

const DashboardOverview = ({ orders, products }: DashboardOverviewProps) => {
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const todayOrders = orders.filter(o => o.createdAt && new Date(o.createdAt) >= today);
  const todaySales = todayOrders
    .filter(o => o.status !== 'cancelled')
    .reduce((sum, o) => sum + o.total, 0);

  const pendingOrders = orders.filter(o => o.status === 'pending').length;
  const deliveredOrders = orders.filter(o => o.status === 'delivered').length;
  const totalRevenue = orders.filter(o => o.status === 'delivered').reduce((sum, o) => sum + o.total, 0);

  const lowStockProducts = products.filter(p => 
    p.stockQuantity !== undefined && p.stockQuantity <= 5 && p.isActive !== false
  );

  // Top selling: count from delivered orders
  const productSales: Record<string, { name: string; nameBn: string; count: number; revenue: number }> = {};
  orders.filter(o => o.status === 'delivered').forEach(order => {
    order.items.forEach(item => {
      if (!productSales[item.id]) {
        productSales[item.id] = { name: item.name, nameBn: item.nameBn, count: 0, revenue: 0 };
      }
      productSales[item.id].count += item.quantity;
      productSales[item.id].revenue += item.price * item.quantity;
    });
  });
  const topSelling = Object.entries(productSales)
    .sort((a, b) => b[1].count - a[1].count)
    .slice(0, 5);

  const stats = [
    { label: 'আজকের অর্ডার', value: todayOrders.length, icon: ShoppingCart, color: 'bg-primary' },
    { label: 'আজকের বিক্রি', value: `৳${todaySales}`, icon: TrendingUp, color: 'bg-secondary' },
    { label: 'পেন্ডিং অর্ডার', value: pendingOrders, icon: Clock, color: 'bg-warning' },
    { label: 'ডেলিভারড', value: deliveredOrders, icon: Truck, color: 'bg-success' },
    { label: 'মোট আয়', value: `৳${totalRevenue}`, icon: CheckCircle, color: 'bg-info' },
    { label: 'মোট পণ্য', value: products.length, icon: Package, color: 'bg-accent' },
  ];

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.05 }}
            className="bg-card rounded-xl p-4 border shadow-sm"
          >
            <div className={`w-10 h-10 rounded-lg ${stat.color} flex items-center justify-center mb-3`}>
              <stat.icon className="h-5 w-5 text-primary-foreground" />
            </div>
            <p className="text-2xl font-bold text-foreground">{stat.value}</p>
            <p className="text-xs text-muted-foreground font-bengali">{stat.label}</p>
          </motion.div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Low Stock Alert */}
        <div className="bg-card rounded-xl p-5 border shadow-sm">
          <h3 className="font-bold font-bengali text-foreground mb-4 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-warning" />
            লো স্টক অ্যালার্ট
          </h3>
          {lowStockProducts.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">সব পণ্যে পর্যাপ্ত স্টক আছে ✅</p>
          ) : (
            <div className="space-y-2">
              {lowStockProducts.map(p => (
                <div key={p.id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div>
                    <p className="text-sm font-medium">{p.nameBn}</p>
                    <p className="text-xs text-muted-foreground">{p.name}</p>
                  </div>
                  <span className="text-sm font-bold text-destructive">{p.stockQuantity} টি বাকি</span>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Top Selling Products */}
        <div className="bg-card rounded-xl p-5 border shadow-sm">
          <h3 className="font-bold font-bengali text-foreground mb-4 flex items-center gap-2">
            <Star className="h-5 w-5 text-warning" />
            টপ সেলিং পণ্য
          </h3>
          {topSelling.length === 0 ? (
            <p className="text-sm text-muted-foreground py-4 text-center">এখনো কোনো বিক্রয় ডেটা নেই</p>
          ) : (
            <div className="space-y-2">
              {topSelling.map(([id, data], index) => (
                <div key={id} className="flex items-center justify-between py-2 border-b last:border-0">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-bold text-muted-foreground">#{index + 1}</span>
                    <div>
                      <p className="text-sm font-medium">{data.nameBn}</p>
                      <p className="text-xs text-muted-foreground">{data.count} বিক্রি</p>
                    </div>
                  </div>
                  <span className="text-sm font-bold text-primary">৳{data.revenue}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Recent Orders */}
      <div className="bg-card rounded-xl p-5 border shadow-sm">
        <h3 className="font-bold font-bengali text-foreground mb-4">সাম্প্রতিক অর্ডার</h3>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>আইডি</TableHead>
                <TableHead>গ্রাহক</TableHead>
                <TableHead>ফোন</TableHead>
                <TableHead>মোট</TableHead>
                <TableHead>পেমেন্ট</TableHead>
                <TableHead>স্ট্যাটাস</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {orders.slice(0, 8).map(order => {
                const status = statusConfig[order.status];
                return (
                  <TableRow key={order.id}>
                    <TableCell className="font-mono text-xs">#{order.id.slice(0, 8).toUpperCase()}</TableCell>
                    <TableCell className="text-sm">{order.customerName || 'N/A'}</TableCell>
                    <TableCell className="text-sm">{order.phone}</TableCell>
                    <TableCell className="font-semibold">৳{order.total}</TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        order.paymentStatus === 'paid' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'
                      }`}>
                        {order.paymentStatus === 'paid' ? 'পেইড' : 'আনপেইড'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`px-2 py-0.5 rounded-full text-xs ${status.color}`}>
                        {status.label}
                      </span>
                    </TableCell>
                  </TableRow>
                );
              })}
              {orders.length === 0 && (
                <TableRow>
                  <TableCell colSpan={6} className="text-center text-muted-foreground py-8">
                    কোনো অর্ডার নেই
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;
