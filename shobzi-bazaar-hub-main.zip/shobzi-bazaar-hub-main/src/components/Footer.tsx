import { Link } from 'react-router-dom';
import { Phone, Mail, MapPin, Facebook, Instagram, MessageCircle } from 'lucide-react';
import { useSiteSettings } from '@/hooks/useSiteSettings';

const Footer = () => {
  const { settings } = useSiteSettings();

  return (
    <footer className="bg-foreground text-card">
      <div className="container py-12">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              {settings.logo ? (
                <img src={settings.logo} alt={settings.storeNameBn} className="h-10 w-10 rounded-lg object-contain" />
              ) : (
                <span className="text-3xl">🥬</span>
              )}
              <div>
                <h2 className="text-xl font-bold font-bengali">{settings.storeNameBn || 'সবজি বাজার'}</h2>
                <span className="text-xs text-card/60">{settings.storeName || 'Sobji Bazar'}</span>
              </div>
            </div>
            <p className="text-card/70 text-sm mb-4">
              তাজা শাকসবজি ও মুদি পণ্য আপনার দোরগোড়ায়। সেরা দাম ও দ্রুত ডেলিভারি।
            </p>
            <div className="flex gap-3">
              {settings.facebookUrl && (
                <a href={settings.facebookUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                  <Facebook className="h-5 w-5" />
                </a>
              )}
              {settings.instagramUrl && (
                <a href={settings.instagramUrl} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                  <Instagram className="h-5 w-5" />
                </a>
              )}
              {settings.whatsappNumber && (
                <a href={`https://wa.me/${settings.whatsappNumber}`} target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </a>
              )}
              {!settings.facebookUrl && !settings.instagramUrl && !settings.whatsappNumber && (
                <>
                  <a href="#" className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                    <Facebook className="h-5 w-5" />
                  </a>
                  <a href="#" className="w-10 h-10 rounded-full bg-card/10 flex items-center justify-center hover:bg-primary transition-colors">
                    <Instagram className="h-5 w-5" />
                  </a>
                </>
              )}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold text-lg mb-4 font-bengali">দ্রুত লিংক</h3>
            <ul className="space-y-2 text-card/70">
              <li><Link to="/" className="hover:text-primary transition-colors">হোম</Link></li>
              <li><Link to="/" className="hover:text-primary transition-colors">সকল পণ্য</Link></li>
              <li><Link to="/" className="hover:text-primary transition-colors">অফার</Link></li>
              <li><Link to="/admin" className="hover:text-primary transition-colors">অ্যাডমিন</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold text-lg mb-4 font-bengali">ক্যাটাগরি</h3>
            <ul className="space-y-2 text-card/70">
              <li><a href="#" className="hover:text-primary transition-colors">শাকসবজি</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">ফলমূল</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">চাল ও ডাল</a></li>
              <li><a href="#" className="hover:text-primary transition-colors">মসলা</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="font-semibold text-lg mb-4 font-bengali">যোগাযোগ</h3>
            <ul className="space-y-3 text-card/70">
              <li className="flex items-center gap-2">
                <Phone className="h-4 w-4 text-primary" />
                <span>{settings.phone || '+৮৮০ ১৭০০-০০০০০০'}</span>
              </li>
              {settings.email && (
                <li className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-primary" />
                  <span>{settings.email}</span>
                </li>
              )}
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-primary mt-0.5" />
                <span>{settings.addressBn || settings.address || 'ঢাকা, বাংলাদেশ'}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-card/10 mt-10 pt-6 text-center text-card/50 text-sm">
          <p>© ২০২৪ {settings.storeNameBn || 'সবজি বাজার'}। সর্বস্বত্ব সংরক্ষিত।</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
