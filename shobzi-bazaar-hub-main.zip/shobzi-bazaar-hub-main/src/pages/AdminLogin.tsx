import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Shield, Mail, Lock, Eye, EyeOff, Loader2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

const AdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login, profile, user, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  // Redirect if already logged in as admin
  useEffect(() => {
    if (!authLoading && user && profile?.isAdmin) {
      navigate('/admin', { replace: true });
    }
  }, [user, profile, authLoading, navigate]);

  // After login, check if user is admin
  useEffect(() => {
    if (loading && user && profile) {
      if (profile.isAdmin) {
        navigate('/admin', { replace: true });
      } else {
        setError('আপনি অ্যাডমিন নন। শুধুমাত্র ওয়েবসাইটের মালিক এই প্যানেল ব্যবহার করতে পারবেন।');
        setLoading(false);
      }
    }
  }, [profile, user, loading, navigate]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!email.trim() || !password.trim()) {
      setError('ইমেইল ও পাসওয়ার্ড দিন');
      return;
    }

    setLoading(true);
    const result = await login(email, password);
    
    if (result.error) {
      setError(result.error);
      setLoading(false);
    }
    // If login successful, the useEffect above will handle redirect/error
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        {/* Logo */}
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 200, delay: 0.2 }}
            className="w-20 h-20 mx-auto rounded-2xl bg-primary/10 flex items-center justify-center mb-4"
          >
            <Shield className="h-10 w-10 text-primary" />
          </motion.div>
          <h1 className="text-2xl font-bold font-bengali text-foreground">
            অ্যাডমিন প্যানেল
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            সবজি বাজার ম্যানেজমেন্ট সিস্টেম
          </p>
        </div>

        {/* Login Form */}
        <div className="card-product p-6 sm:p-8">
          <form onSubmit={handleSubmit} className="space-y-5">
            {error && (
              <motion.div
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-destructive/10 text-destructive text-sm p-3 rounded-lg border border-destructive/20"
              >
                {error}
              </motion.div>
            )}

            <div className="space-y-2">
              <Label htmlFor="email" className="text-sm font-medium">
                ইমেইল অ্যাড্রেস
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-12"
                  disabled={loading}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="password" className="text-sm font-medium">
                পাসওয়ার্ড
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
                <Input
                  id="password"
                  type={showPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 pr-10 h-12"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 btn-primary text-base font-semibold"
              disabled={loading}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                  যাচাই করা হচ্ছে...
                </>
              ) : (
                <>
                  <Shield className="mr-2 h-5 w-5" />
                  অ্যাডমিন লগইন
                </>
              )}
            </Button>
          </form>

          <div className="mt-6 pt-4 border-t text-center">
            <p className="text-xs text-muted-foreground">
              🔒 শুধুমাত্র অনুমোদিত অ্যাডমিনদের জন্য
            </p>
          </div>
        </div>

        {/* Back to home */}
        <div className="text-center mt-6">
          <Button
            variant="ghost"
            onClick={() => navigate('/')}
            className="text-muted-foreground"
          >
            ← হোমে ফিরে যান
          </Button>
        </div>
      </motion.div>
    </div>
  );
};

export default AdminLogin;
