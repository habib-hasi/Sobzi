import { useState, useEffect } from 'react';
import { Menu } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AdminSidebar, { AdminTab } from '@/components/admin/AdminSidebar';
import DashboardOverview from '@/components/admin/DashboardOverview';
import ProductManagement from '@/components/admin/ProductManagement';
import OrderManagement from '@/components/admin/OrderManagement';
import DeliveryManagement from '@/components/admin/DeliveryManagement';
import OfferManagement from '@/components/admin/OfferManagement';
import BannerManagement from '@/components/admin/BannerManagement';
import SiteSettingsPanel from '@/components/admin/SiteSettingsPanel';
import { getAllOrders, getProducts } from '@/services/firebaseService';
import { products as staticProducts } from '@/data/products';
import { Order, Product } from '@/types';
import { toast } from 'sonner';

const tabTitles: Record<AdminTab, string> = {
  dashboard: 'ড্যাশবোর্ড',
  products: 'পণ্য ব্যবস্থাপনা',
  orders: 'অর্ডার ম্যানেজমেন্ট',
  delivery: 'ডেলিভারি সেটিংস',
  offers: 'অফার ও কুপন',
  banners: 'ব্যানার ম্যানেজমেন্ট',
  settings: 'ওয়েবসাইট সেটিংস',
};

const AdminDashboard = () => {
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>(staticProducts);
  const [ordersLoading, setOrdersLoading] = useState(false);

  const fetchOrders = async () => {
    setOrdersLoading(true);
    try {
      const allOrders = await getAllOrders();
      setOrders(allOrders);
    } catch (error) {
      console.error('Error fetching orders:', error);
      toast.error('অর্ডার লোড করতে সমস্যা হয়েছে');
    }
    setOrdersLoading(false);
  };

  const fetchProducts = async () => {
    try {
      const firestoreProducts = await getProducts();
      if (firestoreProducts.length > 0) {
        setProducts(firestoreProducts);
      }
    } catch (error) {
      console.error('Error fetching products:', error);
    }
  };

  useEffect(() => {
    fetchOrders();
    fetchProducts();
  }, []);

  return (
    <div className="flex h-screen bg-background overflow-hidden">
      <AdminSidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        isMobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />

      <main className="flex-1 overflow-y-auto">
        {/* Top Bar */}
        <div className="sticky top-0 z-30 bg-card border-b px-4 py-3 flex items-center gap-3">
          <Button
            variant="ghost" size="icon"
            className="lg:hidden"
            onClick={() => setMobileMenuOpen(true)}
          >
            <Menu className="h-5 w-5" />
          </Button>
          <h1 className="text-lg font-bold font-bengali text-foreground">
            {tabTitles[activeTab]}
          </h1>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-6">
          {activeTab === 'dashboard' && (
            <DashboardOverview orders={orders} products={products} />
          )}
          {activeTab === 'products' && (
            <ProductManagement products={products} onRefresh={fetchProducts} />
          )}
          {activeTab === 'orders' && (
            <OrderManagement orders={orders} loading={ordersLoading} onRefresh={fetchOrders} />
          )}
          {activeTab === 'delivery' && <DeliveryManagement />}
          {activeTab === 'offers' && <OfferManagement />}
          {activeTab === 'banners' && <BannerManagement />}
          {activeTab === 'settings' && <SiteSettingsPanel />}
        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;
