import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Package, Clock, CheckCircle, XCircle, Truck, ChevronDown, ChevronUp } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useAuth } from '@/context/AuthContext';
import { getUserOrders } from '@/services/firebaseService';
import { Order } from '@/types';
import { Button } from '@/components/ui/button';

const statusConfig = {
  pending: { label: 'পেন্ডিং', icon: Clock, color: 'bg-warning/20 text-warning', step: 1 },
  confirmed: { label: 'কনফার্মড', icon: CheckCircle, color: 'bg-info/20 text-info', step: 2 },
  processing: { label: 'প্রসেসিং', icon: Package, color: 'bg-primary/20 text-primary', step: 3 },
  delivered: { label: 'ডেলিভারড', icon: Truck, color: 'bg-success/20 text-success', step: 4 },
  cancelled: { label: 'বাতিল', icon: XCircle, color: 'bg-destructive/20 text-destructive', step: 0 },
};

const trackingSteps = [
  { key: 'pending', label: 'অর্ডার গৃহীত', icon: CheckCircle },
  { key: 'confirmed', label: 'অর্ডার কনফার্মড', icon: CheckCircle },
  { key: 'processing', label: 'প্রসেসিং হচ্ছে', icon: Package },
  { key: 'delivered', label: 'ডেলিভারি সম্পন্ন', icon: Truck },
];

const Orders = () => {
  const { user, loading: authLoading } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrder, setExpandedOrder] = useState<string | null>(null);

  useEffect(() => {
    const fetchOrders = async () => {
      if (user) {
        try {
          const userOrders = await getUserOrders(user.uid);
          setOrders(userOrders);
        } catch (error) {
          console.error('Error fetching orders:', error);
        }
      }
      setLoading(false);
    };

    if (!authLoading) {
      fetchOrders();
    }
  }, [user, authLoading]);

  if (authLoading || loading) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-16 text-center">
          <p className="text-muted-foreground">লোড হচ্ছে...</p>
        </div>
        <Footer />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-16 text-center">
          <p className="text-muted-foreground mb-4">অর্ডার দেখতে লগইন করুন</p>
          <Link to="/auth">
            <Button className="btn-primary rounded-full">লগইন করুন</Button>
          </Link>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <div className="container py-6 sm:py-10">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/">
            <Button variant="ghost" size="icon" className="rounded-full">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold font-bengali">আমার অর্ডার</h1>
        </div>

        {orders.length === 0 ? (
          <div className="text-center py-16">
            <Package className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <p className="text-muted-foreground mb-4">এখনো কোনো অর্ডার নেই</p>
            <Link to="/">
              <Button className="btn-primary rounded-full">কেনাকাটা শুরু করুন</Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {orders.map((order, index) => {
              const status = statusConfig[order.status];
              const StatusIcon = status.icon;
              const isExpanded = expandedOrder === order.id;
              const currentStep = status.step;
              
              return (
                <motion.div
                  key={order.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.05 }}
                  className="card-product overflow-hidden"
                >
                  <div className="p-4 sm:p-6">
                    <div className="flex flex-wrap items-center justify-between gap-4 mb-4">
                      <div>
                        <p className="font-mono text-sm text-muted-foreground">
                          অর্ডার #{order.id.slice(0, 8).toUpperCase()}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {order.createdAt instanceof Date
                            ? order.createdAt.toLocaleDateString('bn-BD')
                            : ''}
                        </p>
                      </div>
                      <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full ${status.color}`}>
                        <StatusIcon className="h-4 w-4" />
                        <span className="text-sm font-medium">{status.label}</span>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-3 mb-4">
                      {order.items.slice(0, 4).map((item) => (
                        <img
                          key={item.id}
                          src={item.image}
                          alt={item.name}
                          className="w-14 h-14 rounded-lg object-cover"
                        />
                      ))}
                      {order.items.length > 4 && (
                        <div className="w-14 h-14 rounded-lg bg-muted flex items-center justify-center text-sm text-muted-foreground">
                          +{order.items.length - 4}
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="text-sm text-muted-foreground">
                        {order.items.length} আইটেম
                      </div>
                      <div className="flex items-center gap-3">
                        <div className="text-lg font-bold text-primary">
                          ৳{order.total}
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setExpandedOrder(isExpanded ? null : order.id)}
                          className="rounded-full text-xs"
                        >
                          {isExpanded ? 'বন্ধ করুন' : 'ট্র্যাক করুন'}
                          {isExpanded ? <ChevronUp className="h-4 w-4 ml-1" /> : <ChevronDown className="h-4 w-4 ml-1" />}
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Order Tracking */}
                  {isExpanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="border-t bg-muted/30 p-4 sm:p-6"
                    >
                      {order.status === 'cancelled' ? (
                        <div className="text-center py-4">
                          <XCircle className="h-10 w-10 mx-auto text-destructive mb-2" />
                          <p className="text-sm text-destructive font-medium">এই অর্ডারটি বাতিল করা হয়েছে</p>
                        </div>
                      ) : (
                        <div className="space-y-1">
                          <h3 className="text-sm font-semibold mb-4">অর্ডার ট্র্যাকিং</h3>
                          <div className="relative">
                            {trackingSteps.map((step, i) => {
                              const isCompleted = currentStep > i + 1 || (currentStep === 4 && i === 3);
                              const isCurrent = currentStep === i + 1;
                              const StepIcon = step.icon;
                              return (
                                <div key={step.key} className="flex items-start gap-3 pb-6 last:pb-0">
                                  <div className="relative flex flex-col items-center">
                                    <div className={`w-8 h-8 rounded-full flex items-center justify-center z-10 ${
                                      isCompleted ? 'bg-success text-success-foreground' :
                                      isCurrent ? 'bg-primary text-primary-foreground' :
                                      'bg-muted text-muted-foreground'
                                    }`}>
                                      <StepIcon className="h-4 w-4" />
                                    </div>
                                    {i < trackingSteps.length - 1 && (
                                      <div className={`w-0.5 h-8 ${
                                        isCompleted ? 'bg-success' : 'bg-border'
                                      }`} />
                                    )}
                                  </div>
                                  <div className="pt-1">
                                    <p className={`text-sm font-medium ${
                                      isCompleted || isCurrent ? 'text-foreground' : 'text-muted-foreground'
                                    }`}>
                                      {step.label}
                                    </p>
                                    {isCurrent && (
                                      <p className="text-xs text-primary mt-0.5">বর্তমান অবস্থা</p>
                                    )}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}

                      {/* Order Details */}
                      <div className="mt-4 pt-4 border-t space-y-2">
                        <h4 className="text-sm font-semibold">অর্ডার বিবরণ</h4>
                        {order.items.map(item => (
                          <div key={item.id} className="flex justify-between text-sm">
                            <span className="text-muted-foreground">{item.nameBn || item.name} × {item.quantity}</span>
                            <span>৳{item.price * item.quantity}</span>
                          </div>
                        ))}
                        <div className="pt-2 border-t flex justify-between text-sm font-semibold">
                          <span>মোট</span>
                          <span className="text-primary">৳{order.total}</span>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
};

export default Orders;
