import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import Header from '@/components/Header';
import HeroBanner from '@/components/HeroBanner';
import CategoryCard from '@/components/CategoryCard';
import ProductCard from '@/components/ProductCard';
import Footer from '@/components/Footer';
import { useProducts } from '@/hooks/useProducts';
import { getBanners } from '@/services/firebaseService';
import { Banner } from '@/types';

const Index = () => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const { products, categories, loading } = useProducts();
  const [offerBanners, setOfferBanners] = useState<Banner[]>([]);

  useEffect(() => {
    const fetchBanners = async () => {
      try {
        const banners = await getBanners();
        setOfferBanners(banners.filter(b => b.type === 'offer' && b.isActive));
      } catch (error) {
        console.error('Error fetching banners:', error);
      }
    };
    fetchBanners();
  }, []);

  const filteredProducts = selectedCategory
    ? products.filter(p => p.category === selectedCategory)
    : products;

  const handleCategoryClick = (categoryId: string) => {
    setSelectedCategory(prev => prev === categoryId ? null : categoryId);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <HeroBanner />

      {/* Categories Section */}
      <section className="container py-8 sm:py-12">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl sm:text-2xl font-bold font-bengali text-foreground">
            ক্যাটাগরি
          </h2>
          {selectedCategory && (
            <button
              onClick={() => setSelectedCategory(null)}
              className="text-sm text-primary hover:underline"
            >
              সব দেখুন
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-4 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 sm:gap-4">
          {categories.map((category, index) => (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <CategoryCard
                category={category}
                onClick={handleCategoryClick}
              />
            </motion.div>
          ))}
        </div>
      </section>

      {/* Products Section */}
      <section className="container py-8 sm:py-12">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold font-bengali text-foreground">
              {selectedCategory 
                ? categories.find(c => c.id === selectedCategory)?.nameBn 
                : 'জনপ্রিয় পণ্য'}
            </h2>
            <p className="text-sm text-muted-foreground mt-1">
              সেরা দামে তাজা পণ্য কিনুন
            </p>
          </div>
        </div>

        {loading ? (
          <div className="text-center py-12 text-muted-foreground">লোড হচ্ছে...</div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
            {filteredProducts.map((product, index) => (
              <motion.div
                key={product.id}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.03 }}
              >
                <ProductCard product={product} />
              </motion.div>
            ))}
          </div>
        )}

        {!loading && filteredProducts.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">এই ক্যাটাগরিতে কোন পণ্য নেই</p>
          </div>
        )}
      </section>

      {/* Dynamic Offer Banner or Default */}
      <section className="container py-8">
        {offerBanners.length > 0 ? (
          <div className="space-y-4">
            {offerBanners.map((banner, index) => (
              <motion.div
                key={banner.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="relative rounded-2xl overflow-hidden"
              >
                <img src={banner.image} alt={banner.titleBn} className="w-full h-48 sm:h-64 object-cover" />
                <div className="absolute inset-0 bg-gradient-to-r from-foreground/80 to-transparent flex items-center">
                  <div className="p-6 sm:p-10 text-card max-w-lg">
                    <h2 className="text-2xl sm:text-3xl font-bold font-bengali mb-2">{banner.titleBn}</h2>
                    {banner.subtitleBn && <p className="text-lg mb-4 opacity-90">{banner.subtitleBn}</p>}
                    {banner.buttonTextBn && (
                      <button className="btn-secondary px-6 py-2 rounded-full font-semibold">
                        {banner.buttonTextBn}
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="hero-gradient rounded-2xl p-6 sm:p-10 text-primary-foreground text-center"
          >
            <h2 className="text-2xl sm:text-3xl font-bold font-bengali mb-3">
              🎁 সাপ্তাহিক অফার!
            </h2>
            <p className="text-lg mb-4 opacity-90">
              ৫০০৳+ অর্ডারে পান ফ্রি ডেলিভারি + বিশেষ উপহার!
            </p>
            <button className="btn-secondary px-8 py-3 rounded-full font-semibold">
              অফার দেখুন
            </button>
          </motion.div>
        )}
      </section>

      <Footer />
    </div>
  );
};

export default Index;
