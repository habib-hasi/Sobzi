import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, Plus, Minus, Share2, Star, ShoppingCart } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ProductCard from '@/components/ProductCard';
import ShareButtons from '@/components/ShareButtons';
import ReviewSection from '@/components/ReviewSection';
import { useProducts } from '@/hooks/useProducts';
import { useCart } from '@/context/CartContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const ProductDetail = () => {
  const { id } = useParams<{ id: string }>();
  const { items, addToCart, updateQuantity } = useCart();
  const { products } = useProducts();

  const product = products.find(p => p.id === id);
  const cartItem = items.find(item => item.id === id);
  const quantity = cartItem?.quantity || 0;

  if (!product) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-20 text-center">
          <h1 className="text-2xl font-bold font-bengali text-foreground mb-4">পণ্য পাওয়া যায়নি</h1>
          <Link to="/" className="text-primary hover:underline">হোম পেজে ফিরে যান</Link>
        </div>
        <Footer />
      </div>
    );
  }

  const similarProducts = products
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 6);

  const shareUrl = window.location.href;

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container py-6 sm:py-10">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
          <Link to="/" className="hover:text-primary transition-colors">হোম</Link>
          <span>/</span>
          <span className="text-foreground font-medium">{product.nameBn}</span>
        </nav>

        {/* Product Detail */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-12">
          {/* Product Image */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="relative"
          >
            <div className="relative aspect-square bg-card rounded-2xl overflow-hidden shadow-card">
              <img
                src={product.image}
                alt={product.nameBn}
                className="w-full h-full object-cover"
              />
              {product.discount && (
                <div className="absolute top-4 left-4">
                  <Badge className="badge-offer text-sm px-3 py-1">
                    {product.discount}% ছাড়
                  </Badge>
                </div>
              )}
              {!product.inStock && (
                <div className="absolute inset-0 bg-foreground/50 flex items-center justify-center">
                  <span className="bg-destructive text-destructive-foreground px-4 py-2 rounded-full font-semibold">
                    স্টক শেষ
                  </span>
                </div>
              )}
            </div>
          </motion.div>

          {/* Product Info */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex flex-col"
          >
            <h1 className="text-2xl sm:text-3xl font-bold font-bengali text-foreground mb-1">
              {product.nameBn}
            </h1>
            <p className="text-muted-foreground mb-4">{product.name}</p>

            {/* Rating placeholder */}
            <div className="flex items-center gap-2 mb-5">
              <div className="flex items-center gap-0.5">
                {[1, 2, 3, 4, 5].map(star => (
                  <Star key={star} className="h-4 w-4 fill-warning text-warning" />
                ))}
              </div>
              <span className="text-sm text-muted-foreground">(২৫ রিভিউ)</span>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-2">
              <span className="text-3xl font-bold text-primary">৳{product.price}</span>
              {product.originalPrice && (
                <span className="text-lg text-muted-foreground line-through">
                  ৳{product.originalPrice}
                </span>
              )}
            </div>
            <p className="text-sm text-muted-foreground mb-6">প্রতি {product.unit}</p>

            {/* Stock status */}
            <div className="mb-6">
              {product.inStock ? (
                <span className="inline-flex items-center gap-1.5 text-sm font-medium text-accent-foreground bg-accent px-3 py-1.5 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-primary"></span>
                  স্টকে আছে
                </span>
              ) : (
                <span className="inline-flex items-center gap-1.5 text-sm font-medium text-destructive-foreground bg-destructive/10 px-3 py-1.5 rounded-full">
                  <span className="w-2 h-2 rounded-full bg-destructive"></span>
                  স্টক শেষ
                </span>
              )}
            </div>

            {/* Description */}
            <div className="bg-muted/50 rounded-xl p-4 mb-6">
              <h3 className="font-semibold text-foreground mb-2">পণ্যের বিবরণ</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {product.description || `${product.nameBn} - সেরা মানের ${product.name}। আমাদের কাছ থেকে তাজা এবং সেরা দামে কিনুন। প্রতি ${product.unit} মাত্র ৳${product.price} টাকায়।`}
              </p>
            </div>

            {/* Add to Cart */}
            {product.inStock && (
              <div className="flex items-center gap-4 mb-6">
                {quantity === 0 ? (
                  <motion.div whileTap={{ scale: 0.95 }} className="flex-1">
                    <Button
                      onClick={() => addToCart(product)}
                      className="w-full btn-primary rounded-full h-12 text-base"
                    >
                      <ShoppingCart className="h-5 w-5 mr-2" />
                      কার্টে যোগ করুন
                    </Button>
                  </motion.div>
                ) : (
                  <div className="flex items-center gap-4 flex-1">
                    <div className="flex items-center bg-accent rounded-full p-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => updateQuantity(product.id, quantity - 1)}
                        className="h-10 w-10 rounded-full hover:bg-primary hover:text-primary-foreground"
                      >
                        <Minus className="h-4 w-4" />
                      </Button>
                      <span className="font-semibold text-lg text-foreground w-10 text-center">{quantity}</span>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => updateQuantity(product.id, quantity + 1)}
                        className="h-10 w-10 rounded-full hover:bg-primary hover:text-primary-foreground"
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    <Link to="/cart" className="flex-1">
                      <Button variant="outline" className="w-full rounded-full h-12">
                        কার্ট দেখুন
                      </Button>
                    </Link>
                  </div>
                )}
              </div>
            )}

            {/* Share */}
            <ShareButtons url={shareUrl} title={`${product.nameBn} - মাত্র ৳${product.price}`} />
          </motion.div>
        </div>

        {/* Reviews Section */}
        <ReviewSection productId={product.id} productName={product.nameBn} />

        {/* Similar Products */}
        {similarProducts.length > 0 && (
          <section className="mt-12 sm:mt-16">
            <h2 className="text-xl sm:text-2xl font-bold font-bengali text-foreground mb-6">
              একই ধরনের পণ্য
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 sm:gap-4">
              {similarProducts.map((p, index) => (
                <motion.div
                  key={p.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.05 }}
                >
                  <ProductCard product={p} />
                </motion.div>
              ))}
            </div>
          </section>
        )}
      </main>

      <Footer />
    </div>
  );
};

export default ProductDetail;
