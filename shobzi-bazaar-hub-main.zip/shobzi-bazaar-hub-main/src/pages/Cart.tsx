import { motion } from 'framer-motion';
import { Trash2, Plus, Minus, ArrowLeft, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useCart } from '@/context/CartContext';
import { useDeliverySettings } from '@/hooks/useDeliverySettings';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useState } from 'react';
import { validateCoupon } from '@/services/firebaseService';
import { Coupon } from '@/types';
import { toast } from 'sonner';

const Cart = () => {
  const { items, updateQuantity, removeFromCart, totalPrice, clearCart } = useCart();
  const { settings: deliverySettings } = useDeliverySettings();
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);

  const deliveryCharge = totalPrice >= deliverySettings.freeDeliveryMinOrder ? 0 : deliverySettings.defaultCharge;
  const couponDiscount = appliedCoupon 
    ? appliedCoupon.discountType === 'percentage' 
      ? Math.min((totalPrice * appliedCoupon.discountValue) / 100, appliedCoupon.maxDiscount || Infinity)
      : appliedCoupon.discountValue
    : 0;
  const finalTotal = totalPrice + deliveryCharge - couponDiscount;

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponLoading(true);
    try {
      const coupon = await validateCoupon(couponCode, totalPrice);
      if (coupon) {
        setAppliedCoupon(coupon);
        toast.success(`কুপন "${coupon.code}" প্রয়োগ হয়েছে!`);
      } else {
        toast.error('অবৈধ কুপন কোড');
      }
    } catch {
      toast.error('কুপন যাচাই করতে সমস্যা');
    }
    setCouponLoading(false);
  };

  if (items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-16 text-center">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
            <ShoppingBag className="h-20 w-20 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold font-bengali mb-2">আপনার কার্ট খালি!</h2>
            <p className="text-muted-foreground mb-6">এখনই কিছু পণ্য যোগ করুন</p>
            <Link to="/"><Button className="btn-primary rounded-full px-8"><ArrowLeft className="mr-2 h-4 w-4" />কেনাকাটা করুন</Button></Link>
          </motion.div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container py-6 sm:py-10">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/"><Button variant="ghost" size="icon" className="rounded-full"><ArrowLeft className="h-5 w-5" /></Button></Link>
          <h1 className="text-2xl font-bold font-bengali">আপনার কার্ট</h1>
          <span className="text-muted-foreground">({items.length} আইটেম)</span>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-4">
            {items.map((item, index) => (
              <motion.div key={item.id} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }} className="card-product p-4 flex gap-4">
                <img src={item.image} alt={item.name} className="w-20 h-20 sm:w-24 sm:h-24 rounded-lg object-cover" />
                <div className="flex-1">
                  <h3 className="font-semibold font-bengali">{item.nameBn}</h3>
                  <p className="text-sm text-muted-foreground">{item.unit}</p>
                  <p className="text-lg font-bold text-primary mt-1">৳{item.price}</p>
                </div>
                <div className="flex flex-col items-end justify-between">
                  <Button variant="ghost" size="icon" onClick={() => removeFromCart(item.id)} className="text-destructive hover:text-destructive hover:bg-destructive/10">
                    <Trash2 className="h-5 w-5" />
                  </Button>
                  <div className="flex items-center gap-2 bg-accent rounded-full p-1">
                    <Button variant="ghost" size="icon" onClick={() => updateQuantity(item.id, item.quantity - 1)} className="h-8 w-8 rounded-full"><Minus className="h-4 w-4" /></Button>
                    <span className="w-8 text-center font-semibold">{item.quantity}</span>
                    <Button variant="ghost" size="icon" onClick={() => updateQuantity(item.id, item.quantity + 1)} className="h-8 w-8 rounded-full"><Plus className="h-4 w-4" /></Button>
                  </div>
                </div>
              </motion.div>
            ))}
            <Button variant="outline" onClick={clearCart} className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground">
              <Trash2 className="mr-2 h-4 w-4" />কার্ট খালি করুন
            </Button>
          </div>

          <div className="lg:col-span-1">
            <div className="card-product p-6 sticky top-24">
              <h2 className="text-xl font-bold font-bengali mb-4">অর্ডার সামারি</h2>
              <div className="space-y-3 mb-4">
                <div className="flex justify-between text-muted-foreground">
                  <span>সাবটোটাল</span><span>৳{totalPrice}</span>
                </div>
                <div className="flex justify-between text-muted-foreground">
                  <span>ডেলিভারি চার্জ</span>
                  <span className={deliveryCharge === 0 ? 'text-success' : ''}>{deliveryCharge === 0 ? 'ফ্রি!' : `৳${deliveryCharge}`}</span>
                </div>
                {couponDiscount > 0 && (
                  <div className="flex justify-between text-success">
                    <span>কুপন ছাড়</span><span>-৳{couponDiscount}</span>
                  </div>
                )}
                {deliveryCharge > 0 && (
                  <p className="text-xs text-muted-foreground">৳{deliverySettings.freeDeliveryMinOrder - totalPrice} আরো কিনলে ফ্রি ডেলিভারি!</p>
                )}
              </div>

              <div className="border-t border-border pt-4 mb-6">
                <div className="flex justify-between text-lg font-bold">
                  <span>মোট</span><span className="text-primary">৳{finalTotal}</span>
                </div>
              </div>

              {/* Promo Code */}
              <div className="flex gap-2 mb-6">
                <Input placeholder="প্রোমো কোড" value={couponCode} onChange={e => setCouponCode(e.target.value)} className="rounded-full" />
                <Button variant="outline" className="rounded-full" onClick={handleApplyCoupon} disabled={couponLoading}>
                  {couponLoading ? '...' : 'প্রয়োগ'}
                </Button>
              </div>
              {appliedCoupon && (
                <div className="flex items-center justify-between bg-accent px-3 py-2 rounded-lg mb-4 text-sm">
                  <span>✅ {appliedCoupon.code}</span>
                  <button onClick={() => { setAppliedCoupon(null); setCouponCode(''); }} className="text-destructive text-xs">সরান</button>
                </div>
              )}

              <Link to="/checkout" className="block w-full">
                <Button className="w-full btn-primary rounded-full h-12 text-lg">চেকআউট করুন</Button>
              </Link>
              <p className="text-xs text-center text-muted-foreground mt-4">🔒 নিরাপদ পেমেন্ট গ্যারান্টি</p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default Cart;
