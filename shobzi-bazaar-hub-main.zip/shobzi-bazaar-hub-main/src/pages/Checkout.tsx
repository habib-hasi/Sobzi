import { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, MapPin, Phone, CreditCard, Truck, CheckCircle, Tag } from 'lucide-react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { useCart } from '@/context/CartContext';
import { useAuth } from '@/context/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { createOrder, getDeliverySettings, validateCoupon } from '@/services/firebaseService';
import { DeliverySettings, Coupon } from '@/types';
import { toast } from 'sonner';
import { z } from 'zod';

const checkoutSchema = z.object({
  name: z.string().min(2, 'নাম কমপক্ষে ২ অক্ষরের হতে হবে'),
  phone: z.string().regex(/^01[3-9]\d{8}$/, 'সঠিক ফোন নম্বর দিন (যেমন: 01712345678)'),
  address: z.string().min(10, 'বিস্তারিত ঠিকানা দিন (কমপক্ষে ১০ অক্ষর)'),
});

const Checkout = () => {
  const { items, totalPrice, clearCart } = useCart();
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  
  const [name, setName] = useState(profile?.name || '');
  const [phone, setPhone] = useState(profile?.phone || '');
  const [address, setAddress] = useState(profile?.address || '');
  const [paymentMethod, setPaymentMethod] = useState('cod');
  const [loading, setLoading] = useState(false);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderId, setOrderId] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  // Delivery & Coupon
  const [deliverySettings, setDeliverySettings] = useState<DeliverySettings | null>(null);
  const [selectedArea, setSelectedArea] = useState('');
  const [couponCode, setCouponCode] = useState('');
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponLoading, setCouponLoading] = useState(false);

  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const settings = await getDeliverySettings();
        setDeliverySettings(settings);
      } catch (error) {
        console.error('Error fetching delivery settings:', error);
      }
    };
    fetchSettings();
  }, []);

  // Calculate delivery charge
  const getDeliveryCharge = () => {
    if (!deliverySettings) return totalPrice >= 500 ? 0 : 50;
    
    // Free delivery from coupon
    if (appliedCoupon?.freeDelivery) return 0;
    
    // Free delivery from min order
    if (totalPrice >= deliverySettings.freeDeliveryMinOrder) return 0;
    
    // Area-based charge
    if (selectedArea && deliverySettings.areas.length > 0) {
      const area = deliverySettings.areas.find(a => a.id === selectedArea);
      return area?.charge || deliverySettings.defaultCharge;
    }
    
    return deliverySettings.defaultCharge;
  };

  // Calculate coupon discount
  const getCouponDiscount = () => {
    if (!appliedCoupon) return 0;
    if (appliedCoupon.discountType === 'percentage') {
      const discount = (totalPrice * appliedCoupon.discountValue) / 100;
      return appliedCoupon.maxDiscount ? Math.min(discount, appliedCoupon.maxDiscount) : discount;
    }
    return appliedCoupon.discountValue;
  };

  const deliveryCharge = getDeliveryCharge();
  const couponDiscount = getCouponDiscount();
  const finalTotal = totalPrice + deliveryCharge - couponDiscount;

  const handleApplyCoupon = async () => {
    if (!couponCode.trim()) return;
    setCouponLoading(true);
    try {
      const coupon = await validateCoupon(couponCode, totalPrice);
      if (coupon) {
        setAppliedCoupon(coupon);
        toast.success(`কুপন "${coupon.code}" প্রয়োগ হয়েছে!`);
      } else {
        toast.error('অবৈধ কুপন কোড বা শর্ত পূরণ হয়নি');
      }
    } catch (error) {
      toast.error('কুপন যাচাই করতে সমস্যা হয়েছে');
    }
    setCouponLoading(false);
  };

  const handleRemoveCoupon = () => {
    setAppliedCoupon(null);
    setCouponCode('');
    toast.info('কুপন সরানো হয়েছে');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrors({});
    
    const validation = checkoutSchema.safeParse({ name, phone, address });
    if (!validation.success) {
      const newErrors: Record<string, string> = {};
      validation.error.errors.forEach(err => {
        if (err.path[0]) newErrors[err.path[0] as string] = err.message;
      });
      setErrors(newErrors);
      return;
    }

    setLoading(true);

    try {
      const userId = user?.uid || 'guest-' + Date.now();
      const areaName = selectedArea 
        ? deliverySettings?.areas.find(a => a.id === selectedArea)?.nameBn 
        : undefined;
      
      const newOrderId = await createOrder(
        userId, items, finalTotal, address, phone, name,
        totalPrice, deliveryCharge, paymentMethod,
        appliedCoupon?.code, couponDiscount, areaName
      );
      
      setOrderId(newOrderId);
      setOrderPlaced(true);
      clearCart();
      toast.success('অর্ডার সফলভাবে সম্পন্ন হয়েছে!');
    } catch (error) {
      console.error('Order error:', error);
      toast.error('অর্ডার দিতে সমস্যা হয়েছে। আবার চেষ্টা করুন।');
    }

    setLoading(false);
  };

  if (items.length === 0 && !orderPlaced) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-16 text-center">
          <p className="text-muted-foreground mb-4">আপনার কার্ট খালি</p>
          <Link to="/"><Button className="btn-primary rounded-full">কেনাকাটা করুন</Button></Link>
        </div>
        <Footer />
      </div>
    );
  }

  if (orderPlaced) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container py-16">
          <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} className="max-w-lg mx-auto text-center card-product p-8">
            <div className="w-20 h-20 mx-auto mb-6 rounded-full bg-success/20 flex items-center justify-center">
              <CheckCircle className="h-10 w-10 text-success" />
            </div>
            <h1 className="text-2xl font-bold font-bengali mb-2">অর্ডার সম্পন্ন!</h1>
            <p className="text-muted-foreground mb-4">আপনার অর্ডার সফলভাবে গ্রহণ করা হয়েছে</p>
            <div className="bg-muted p-4 rounded-lg mb-6">
              <p className="text-sm text-muted-foreground">অর্ডার আইডি</p>
              <p className="font-mono font-bold text-primary">#{orderId.slice(0, 8).toUpperCase()}</p>
            </div>
            <div className="space-y-2 text-sm text-muted-foreground mb-6">
              <p>📞 আমরা শীঘ্রই আপনার সাথে যোগাযোগ করব</p>
              <p>🚚 {deliverySettings?.estimatedTime || '২-৪ ঘন্টার'} মধ্যে ডেলিভারি হবে</p>
            </div>
            <div className="flex gap-3 justify-center">
              <Link to="/"><Button className="btn-primary rounded-full">হোম এ যান</Button></Link>
              {user && <Link to="/orders"><Button variant="outline" className="rounded-full">আমার অর্ডার</Button></Link>}
            </div>
          </motion.div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container py-6 sm:py-10">
        <div className="flex items-center gap-4 mb-6">
          <Link to="/cart"><Button variant="ghost" size="icon" className="rounded-full"><ArrowLeft className="h-5 w-5" /></Button></Link>
          <h1 className="text-2xl font-bold font-bengali">চেকআউট</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 space-y-6">
              {/* Delivery Info */}
              <div className="card-product p-6">
                <h2 className="text-lg font-bold font-bengali mb-4 flex items-center gap-2">
                  <Truck className="h-5 w-5 text-primary" /> ডেলিভারি তথ্য
                </h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="font-bengali">আপনার নাম *</Label>
                    <Input id="name" placeholder="রহিম আহমেদ" value={name} onChange={e => setName(e.target.value)} className={errors.name ? 'border-destructive' : ''} />
                    {errors.name && <p className="text-xs text-destructive">{errors.name}</p>}
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="font-bengali">ফোন নম্বর *</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                      <Input id="phone" placeholder="01712345678" value={phone} onChange={e => setPhone(e.target.value)} className={`pl-10 ${errors.phone ? 'border-destructive' : ''}`} />
                    </div>
                    {errors.phone && <p className="text-xs text-destructive">{errors.phone}</p>}
                  </div>
                </div>

                {/* Delivery Area */}
                {deliverySettings && deliverySettings.areas.length > 0 && (
                  <div className="mt-4 space-y-2">
                    <Label className="font-bengali">ডেলিভারি এলাকা</Label>
                    <Select value={selectedArea} onValueChange={setSelectedArea}>
                      <SelectTrigger><SelectValue placeholder="এলাকা বাছাই করুন" /></SelectTrigger>
                      <SelectContent>
                        {deliverySettings.areas.filter(a => a.isActive).map(area => (
                          <SelectItem key={area.id} value={area.id}>
                            {area.nameBn || area.name} - ৳{area.charge}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}

                <div className="mt-4 space-y-2">
                  <Label htmlFor="address" className="font-bengali">সম্পূর্ণ ঠিকানা *</Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Textarea id="address" placeholder="বাসা নং, রোড নং, এলাকা, থানা, জেলা..." value={address} onChange={e => setAddress(e.target.value)} className={`pl-10 min-h-[100px] ${errors.address ? 'border-destructive' : ''}`} />
                  </div>
                  {errors.address && <p className="text-xs text-destructive">{errors.address}</p>}
                </div>
              </div>

              {/* Payment Method */}
              <div className="card-product p-6">
                <h2 className="text-lg font-bold font-bengali mb-4 flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-primary" /> পেমেন্ট পদ্ধতি
                </h2>
                <RadioGroup value={paymentMethod} onValueChange={setPaymentMethod}>
                  <div className="flex items-center space-x-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer">
                    <RadioGroupItem value="cod" id="cod" />
                    <Label htmlFor="cod" className="flex-1 cursor-pointer">
                      <div className="font-medium font-bengali">ক্যাশ অন ডেলিভারি</div>
                      <div className="text-sm text-muted-foreground">পণ্য হাতে পেয়ে পেমেন্ট করুন</div>
                    </Label>
                    <span className="text-2xl">💵</span>
                  </div>
                  <div className="flex items-center space-x-3 p-4 border rounded-lg hover:bg-muted/50 cursor-pointer">
                    <RadioGroupItem value="bkash" id="bkash" />
                    <Label htmlFor="bkash" className="flex-1 cursor-pointer">
                      <div className="font-medium font-bengali">বিকাশ</div>
                      <div className="text-sm text-muted-foreground">বিকাশ দিয়ে পেমেন্ট করুন</div>
                    </Label>
                    <span className="text-2xl">📱</span>
                  </div>
                </RadioGroup>
              </div>
            </div>

            {/* Order Summary */}
            <div className="lg:col-span-1">
              <div className="card-product p-6 sticky top-24">
                <h2 className="text-lg font-bold font-bengali mb-4">অর্ডার সামারি</h2>

                <div className="space-y-3 mb-4 max-h-48 overflow-y-auto">
                  {items.map(item => (
                    <div key={item.id} className="flex gap-3 text-sm">
                      <img src={item.image} alt={item.name} className="w-12 h-12 rounded object-cover" />
                      <div className="flex-1">
                        <p className="font-medium font-bengali line-clamp-1">{item.nameBn}</p>
                        <p className="text-muted-foreground">{item.quantity} × ৳{item.price}</p>
                      </div>
                      <p className="font-medium">৳{item.price * item.quantity}</p>
                    </div>
                  ))}
                </div>

                {/* Coupon */}
                <div className="mb-4">
                  {appliedCoupon ? (
                    <div className="flex items-center justify-between bg-accent p-3 rounded-lg">
                      <div className="flex items-center gap-2">
                        <Tag className="h-4 w-4 text-primary" />
                        <span className="text-sm font-medium">{appliedCoupon.code}</span>
                      </div>
                      <button onClick={handleRemoveCoupon} className="text-xs text-destructive hover:underline">সরান</button>
                    </div>
                  ) : (
                    <div className="flex gap-2">
                      <Input placeholder="কুপন কোড" value={couponCode} onChange={e => setCouponCode(e.target.value)} className="rounded-full" />
                      <Button type="button" variant="outline" className="rounded-full" onClick={handleApplyCoupon} disabled={couponLoading}>
                        {couponLoading ? '...' : 'প্রয়োগ'}
                      </Button>
                    </div>
                  )}
                </div>

                <div className="border-t pt-4 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">সাবটোটাল</span>
                    <span>৳{totalPrice}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-muted-foreground">ডেলিভারি</span>
                    <span className={deliveryCharge === 0 ? 'text-success' : ''}>
                      {deliveryCharge === 0 ? 'ফ্রি!' : `৳${deliveryCharge}`}
                    </span>
                  </div>
                  {couponDiscount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">কুপন ছাড়</span>
                      <span className="text-success">-৳{couponDiscount}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-lg font-bold pt-2 border-t">
                    <span>মোট</span>
                    <span className="text-primary">৳{finalTotal}</span>
                  </div>
                </div>

                <Button type="submit" disabled={loading} className="w-full btn-primary rounded-full h-12 text-base mt-6">
                  {loading ? 'অপেক্ষা করুন...' : 'অর্ডার কনফার্ম করুন'}
                </Button>
                <p className="text-xs text-center text-muted-foreground mt-4">🔒 আপনার তথ্য সম্পূর্ণ নিরাপদ</p>
              </div>
            </div>
          </div>
        </form>
      </div>
      <Footer />
    </div>
  );
};

export default Checkout;
