import { Product, Category } from '@/types';

// Category images
import vegetablesImg from '@/assets/category-vegetables.jpg';
import fruitsImg from '@/assets/category-fruits.jpg';
import riceDalImg from '@/assets/category-rice-dal.jpg';
import spicesImg from '@/assets/category-spices.jpg';
import fishMeatImg from '@/assets/category-fish-meat.jpg';
import snacksImg from '@/assets/category-snacks.jpg';

// Product images
import potatoImg from '@/assets/products/potato.jpg';
import onionImg from '@/assets/products/onion.jpg';
import greenChiliImg from '@/assets/products/green-chili.jpg';
import tomatoImg from '@/assets/products/tomato.jpg';
import riceImg from '@/assets/products/rice.jpg';
import dalImg from '@/assets/products/dal.jpg';
import oilImg from '@/assets/products/oil.jpg';
import appleImg from '@/assets/products/apple.jpg';
import bananaImg from '@/assets/products/banana.jpg';
import turmericImg from '@/assets/products/turmeric.jpg';
import chiliPowderImg from '@/assets/products/chili-powder.jpg';
import milkImg from '@/assets/products/milk.jpg';

export const categories: Category[] = [
  {
    id: 'vegetables',
    name: 'Vegetables',
    nameBn: 'শাকসবজি',
    icon: '🥬',
    image: vegetablesImg
  },
  {
    id: 'fruits',
    name: 'Fruits',
    nameBn: 'ফলমূল',
    icon: '🍎',
    image: fruitsImg
  },
  {
    id: 'rice-dal',
    name: 'Rice & Dal',
    nameBn: 'চাল ও ডাল',
    icon: '🍚',
    image: riceDalImg
  },
  {
    id: 'spices',
    name: 'Spices',
    nameBn: 'মসলা',
    icon: '🌶️',
    image: spicesImg
  },
  {
    id: 'oil',
    name: 'Cooking Oil',
    nameBn: 'তেল',
    icon: '🫒',
    image: oilImg
  },
  {
    id: 'fish-meat',
    name: 'Fish & Meat',
    nameBn: 'মাছ ও মাংস',
    icon: '🐟',
    image: fishMeatImg
  },
  {
    id: 'dairy',
    name: 'Dairy',
    nameBn: 'দুগ্ধজাত',
    icon: '🥛',
    image: milkImg
  },
  {
    id: 'snacks',
    name: 'Snacks',
    nameBn: 'স্ন্যাকস',
    icon: '🍪',
    image: snacksImg
  }
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Fresh Potato',
    nameBn: 'তাজা আলু',
    price: 45,
    originalPrice: 55,
    unit: '1 kg',
    image: potatoImg,
    category: 'vegetables',
    inStock: true,
    discount: 18
  },
  {
    id: '2',
    name: 'Red Onion',
    nameBn: 'লাল পেঁয়াজ',
    price: 80,
    originalPrice: 95,
    unit: '1 kg',
    image: onionImg,
    category: 'vegetables',
    inStock: true,
    discount: 16
  },
  {
    id: '3',
    name: 'Green Chili',
    nameBn: 'কাঁচা মরিচ',
    price: 120,
    unit: '500 gm',
    image: greenChiliImg,
    category: 'vegetables',
    inStock: true
  },
  {
    id: '4',
    name: 'Tomato',
    nameBn: 'টমেটো',
    price: 60,
    originalPrice: 70,
    unit: '500 gm',
    image: tomatoImg,
    category: 'vegetables',
    inStock: true,
    discount: 14
  },
  {
    id: '5',
    name: 'Miniket Rice',
    nameBn: 'মিনিকেট চাল',
    price: 85,
    unit: '1 kg',
    image: riceImg,
    category: 'rice-dal',
    inStock: true
  },
  {
    id: '6',
    name: 'Masoor Dal',
    nameBn: 'মসুর ডাল',
    price: 145,
    originalPrice: 160,
    unit: '1 kg',
    image: dalImg,
    category: 'rice-dal',
    inStock: true,
    discount: 10
  },
  {
    id: '7',
    name: 'Soybean Oil',
    nameBn: 'সয়াবিন তেল',
    price: 180,
    unit: '1 ltr',
    image: oilImg,
    category: 'oil',
    inStock: true
  },
  {
    id: '8',
    name: 'Fresh Apple',
    nameBn: 'তাজা আপেল',
    price: 280,
    originalPrice: 320,
    unit: '1 kg',
    image: appleImg,
    category: 'fruits',
    inStock: true,
    discount: 12
  },
  {
    id: '9',
    name: 'Banana',
    nameBn: 'কলা',
    price: 60,
    unit: '1 dozen',
    image: bananaImg,
    category: 'fruits',
    inStock: true
  },
  {
    id: '10',
    name: 'Turmeric Powder',
    nameBn: 'হলুদ গুঁড়া',
    price: 95,
    unit: '200 gm',
    image: turmericImg,
    category: 'spices',
    inStock: true
  },
  {
    id: '11',
    name: 'Chili Powder',
    nameBn: 'মরিচ গুঁড়া',
    price: 110,
    unit: '200 gm',
    image: chiliPowderImg,
    category: 'spices',
    inStock: true
  },
  {
    id: '12',
    name: 'Fresh Milk',
    nameBn: 'তাজা দুধ',
    price: 90,
    unit: '1 ltr',
    image: milkImg,
    category: 'dairy',
    inStock: true
  }
];
