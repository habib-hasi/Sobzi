import { 
  collection, addDoc, updateDoc, doc, getDocs, getDoc, setDoc,
  query, where, orderBy, Timestamp, deleteDoc 
} from 'firebase/firestore';
import { db } from '@/lib/firebase';
import { Order, Product, CartItem, DeliverySettings, DeliveryArea, Coupon, Banner, SiteSettings } from '@/types';

// ==================== ORDERS ====================

export const createOrder = async (
  userId: string,
  items: CartItem[],
  total: number,
  address: string,
  phone: string,
  customerName: string,
  subtotal: number = total,
  deliveryCharge: number = 0,
  paymentMethod: string = 'cod',
  couponCode?: string,
  couponDiscount?: number,
  deliveryArea?: string
): Promise<string> => {
  const orderRef = await addDoc(collection(db, 'orders'), {
    userId,
    items: items.map(item => ({
      id: item.id,
      name: item.name,
      nameBn: item.nameBn,
      price: item.price,
      quantity: item.quantity,
      unit: item.unit,
      image: item.image
    })),
    total,
    subtotal,
    deliveryCharge,
    couponCode: couponCode || null,
    couponDiscount: couponDiscount || 0,
    address,
    phone,
    customerName,
    paymentMethod,
    paymentStatus: 'unpaid',
    deliveryArea: deliveryArea || null,
    status: 'pending',
    createdAt: Timestamp.now()
  });
  return orderRef.id;
};

export const getUserOrders = async (userId: string): Promise<Order[]> => {
  const q = query(
    collection(db, 'orders'),
    where('userId', '==', userId)
  );
  const snapshot = await getDocs(q);
  const orders = snapshot.docs.map(d => ({
    id: d.id,
    ...d.data(),
    createdAt: d.data().createdAt?.toDate()
  })) as Order[];
  return orders.sort((a, b) => (b.createdAt?.getTime() || 0) - (a.createdAt?.getTime() || 0));
};

export const getAllOrders = async (): Promise<Order[]> => {
  const q = query(collection(db, 'orders'), orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => ({
    id: d.id,
    ...d.data(),
    createdAt: d.data().createdAt?.toDate()
  })) as Order[];
};

export const updateOrderStatus = async (orderId: string, status: Order['status']): Promise<void> => {
  await updateDoc(doc(db, 'orders', orderId), { status });
};

export const updateOrderPaymentStatus = async (orderId: string, paymentStatus: 'unpaid' | 'paid'): Promise<void> => {
  await updateDoc(doc(db, 'orders', orderId), { paymentStatus });
};

// ==================== PRODUCTS ====================

export const addProduct = async (product: Omit<Product, 'id'>): Promise<string> => {
  const productRef = await addDoc(collection(db, 'products'), {
    ...product,
    isActive: product.isActive !== false,
    createdAt: Timestamp.now()
  });
  return productRef.id;
};

export const updateProduct = async (productId: string, updates: Partial<Product>): Promise<void> => {
  await updateDoc(doc(db, 'products', productId), updates);
};

export const deleteProduct = async (productId: string): Promise<void> => {
  await deleteDoc(doc(db, 'products', productId));
};

export const getProducts = async (): Promise<Product[]> => {
  const snapshot = await getDocs(collection(db, 'products'));
  return snapshot.docs.map(d => ({
    id: d.id,
    ...d.data()
  })) as Product[];
};

// ==================== DELIVERY SETTINGS ====================

export const getDeliverySettings = async (): Promise<DeliverySettings> => {
  const docRef = doc(db, 'settings', 'delivery');
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return docSnap.data() as DeliverySettings;
  }
  return {
    defaultCharge: 50,
    freeDeliveryMinOrder: 500,
    areas: [],
    estimatedTime: '২-৪ ঘন্টা'
  };
};

export const saveDeliverySettings = async (settings: DeliverySettings): Promise<void> => {
  await setDoc(doc(db, 'settings', 'delivery'), settings);
};

// ==================== COUPONS ====================

export const getCoupons = async (): Promise<Coupon[]> => {
  const snapshot = await getDocs(collection(db, 'coupons'));
  return snapshot.docs.map(d => ({
    id: d.id,
    ...d.data(),
    expiresAt: d.data().expiresAt?.toDate?.() || null
  })) as Coupon[];
};

export const addCoupon = async (coupon: Omit<Coupon, 'id'>): Promise<string> => {
  const ref = await addDoc(collection(db, 'coupons'), {
    ...coupon,
    expiresAt: coupon.expiresAt ? Timestamp.fromDate(coupon.expiresAt) : null,
    usageCount: 0
  });
  return ref.id;
};

export const updateCoupon = async (couponId: string, updates: Partial<Coupon>): Promise<void> => {
  const data: any = { ...updates };
  if (data.expiresAt instanceof Date) {
    data.expiresAt = Timestamp.fromDate(data.expiresAt);
  }
  await updateDoc(doc(db, 'coupons', couponId), data);
};

export const deleteCoupon = async (couponId: string): Promise<void> => {
  await deleteDoc(doc(db, 'coupons', couponId));
};

export const validateCoupon = async (code: string, orderTotal: number): Promise<Coupon | null> => {
  const q = query(collection(db, 'coupons'), where('code', '==', code.toUpperCase()), where('isActive', '==', true));
  const snapshot = await getDocs(q);
  if (snapshot.empty) return null;
  
  const coupon = { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Coupon;
  
  if (coupon.expiresAt && new Date() > new Date(coupon.expiresAt)) return null;
  if (coupon.minOrderAmount && orderTotal < coupon.minOrderAmount) return null;
  
  return coupon;
};

// ==================== BANNERS ====================

export const getBanners = async (): Promise<Banner[]> => {
  const q = query(collection(db, 'banners'), orderBy('order', 'asc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map(d => ({
    id: d.id,
    ...d.data()
  })) as Banner[];
};

export const addBanner = async (banner: Omit<Banner, 'id'>): Promise<string> => {
  const ref = await addDoc(collection(db, 'banners'), banner);
  return ref.id;
};

export const updateBanner = async (bannerId: string, updates: Partial<Banner>): Promise<void> => {
  await updateDoc(doc(db, 'banners', bannerId), updates);
};

export const deleteBanner = async (bannerId: string): Promise<void> => {
  await deleteDoc(doc(db, 'banners', bannerId));
};

// ==================== SITE SETTINGS ====================

export const getSiteSettings = async (): Promise<SiteSettings> => {
  const docRef = doc(db, 'settings', 'site');
  const docSnap = await getDoc(docRef);
  if (docSnap.exists()) {
    return docSnap.data() as SiteSettings;
  }
  return {
    storeName: 'Sobji Bazar',
    storeNameBn: 'সবজি বাজার',
    phone: '+৮৮০ ১৭০০-০০০০০০',
    email: 'info@sobjibazar.com',
    address: 'গুলশান-২, ঢাকা-১২১২, বাংলাদেশ',
    deliveryTime: '২-৪ ঘন্টা',
    openTime: '08:00',
    closeTime: '22:00',
    isOpen: true
  };
};

export const saveSiteSettings = async (settings: SiteSettings): Promise<void> => {
  await setDoc(doc(db, 'settings', 'site'), settings);
};
