const IMGBB_API_KEY = '7fe289f449afa882f067141c904a7dd9';

export const uploadToImgBB = async (file: File): Promise<string> => {
  const formData = new FormData();
  formData.append('image', file);
  formData.append('key', IMGBB_API_KEY);

  const response = await fetch('https://api.imgbb.com/1/upload', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    throw new Error('ছবি আপলোড করতে সমস্যা হয়েছে');
  }

  const data = await response.json();
  
  if (!data.success) {
    throw new Error('ছবি আপলোড ব্যর্থ হয়েছে');
  }

  return data.data.display_url;
};

export const uploadBase64ToImgBB = async (base64: string): Promise<string> => {
  const formData = new FormData();
  // Remove data:image prefix if present
  const cleanBase64 = base64.replace(/^data:image\/\w+;base64,/, '');
  formData.append('image', cleanBase64);
  formData.append('key', IMGBB_API_KEY);

  const response = await fetch('https://api.imgbb.com/1/upload', {
    method: 'POST',
    body: formData,
  });

  if (!response.ok) {
    throw new Error('ছবি আপলোড করতে সমস্যা হয়েছে');
  }

  const data = await response.json();
  
  if (!data.success) {
    throw new Error('ছবি আপলোড ব্যর্থ হয়েছে');
  }

  return data.data.display_url;
};
