import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyAXuB8rdMZLQ68092uU0CZSEpZ7vkGNKM4",
  authDomain: "cholokini-38555.firebaseapp.com",
  projectId: "cholokini-38555",
  storageBucket: "cholokini-38555.firebasestorage.app",
  messagingSenderId: "894615954788",
  appId: "1:894615954788:web:686080cc8b92c92c278671",
  measurementId: "G-Q2DYVC0QKM"
};

const app = initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);
export default app;
