import { useState, useEffect } from 'react';
import { getDeliverySettings } from '@/services/firebaseService';
import { DeliverySettings } from '@/types';

const defaultSettings: DeliverySettings = {
  defaultCharge: 50,
  freeDeliveryMinOrder: 500,
  areas: [],
  estimatedTime: '২-৪ ঘন্টা'
};

export const useDeliverySettings = () => {
  const [settings, setSettings] = useState<DeliverySettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const s = await getDeliverySettings();
        setSettings(s);
      } catch (error) {
        console.error('Error fetching delivery settings:', error);
      }
      setLoading(false);
    };
    fetch();
  }, []);

  return { settings, loading };
};
