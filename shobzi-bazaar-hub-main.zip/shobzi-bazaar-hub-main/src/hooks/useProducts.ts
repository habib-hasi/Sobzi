import { useState, useEffect } from 'react';
import { getProducts } from '@/services/firebaseService';
import { products as staticProducts, categories } from '@/data/products';
import { Product } from '@/types';

export const useProducts = () => {
  const [products, setProducts] = useState<Product[]>(staticProducts);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const firestoreProducts = await getProducts();
        if (firestoreProducts.length > 0) {
          // Merge: show Firestore products + static products not in Firestore
          const firestoreIds = new Set(firestoreProducts.map(p => p.id));
          const combined = [
            ...firestoreProducts.filter(p => p.isActive !== false),
            ...staticProducts.filter(p => !firestoreIds.has(p.id))
          ];
          setProducts(combined);
        }
      } catch (error) {
        console.error('Error fetching products:', error);
        // Fall back to static products
      }
      setLoading(false);
    };
    fetchProducts();
  }, []);

  return { products, categories, loading, refetch: async () => {
    setLoading(true);
    try {
      const firestoreProducts = await getProducts();
      if (firestoreProducts.length > 0) {
        setProducts(firestoreProducts.filter(p => p.isActive !== false));
      }
    } catch (error) {
      console.error('Error refetching products:', error);
    }
    setLoading(false);
  }};
};
