import { useState, useEffect } from 'react';
import { getSiteSettings } from '@/services/firebaseService';
import { SiteSettings } from '@/types';

const defaultSettings: SiteSettings = {
  storeName: 'Sobji Bazar',
  storeNameBn: 'সবজি বাজার',
  phone: '+৮৮০ ১৭০০-০০০০০০',
  email: 'info@sobjibazar.com',
  address: 'গুলশান-২, ঢাকা-১২১২, বাংলাদেশ',
  deliveryTime: '২-৪ ঘন্টা',
  openTime: '08:00',
  closeTime: '22:00',
  isOpen: true
};

export const useSiteSettings = () => {
  const [settings, setSettings] = useState<SiteSettings>(defaultSettings);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      try {
        const s = await getSiteSettings();
        setSettings(s);
      } catch (error) {
        console.error('Error fetching site settings:', error);
      }
      setLoading(false);
    };
    fetch();
  }, []);

  return { settings, loading };
};
